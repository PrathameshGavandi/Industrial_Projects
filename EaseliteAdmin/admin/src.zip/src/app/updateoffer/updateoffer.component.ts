import { Component, OnInit } from '@angular/core';
import { Offer } from '../Class';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { WebService } from '../Service';

@Component({
  selector: 'app-updateoffer',
  templateUrl: './updateoffer.component.html',
  styleUrls: ['./updateoffer.component.scss']
})
export class UpdateofferComponent implements OnInit {

  offer: Offer;  // Use the new entity type
  Id: any;   // ID of the entity to update

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private service: WebService
  ) {
    this.offer = new Offer();

    // Fetch entity details based on ID from the URL
    this.route.params.subscribe(params => {
      this.Id = params['Id']; // Adjust this based on your route

      // Fetch details of the entity by ID
      this.service.GetOfferById(this.Id).subscribe(result => {
        this.offer = result;
      });
    });
  }

  ngOnInit(): void {
    // You can add any initialization logic here if needed
  }

  onUpdate() {
    // Update the entity details
    this.service.UpdateOffer(this.offer).subscribe(result => {
      if (result === 0) {
        Swal.fire({
          icon: 'error',
          title: 'Update Failed',
          text: 'Something went wrong! Please try again.',
          confirmButtonText: 'OK'
        });
      } else {
        Swal.fire({
          icon: 'success',
          title: 'Update Successful',
          text: 'The entity details have been updated successfully.',
          confirmButtonText: 'OK'
        }).then(() => {
          this.router.navigate(['/offerlist']); // Adjust navigation path as needed
        });
      }
    }, error => {
      Swal.fire({
        icon: 'error',
        title: 'Update Error',
        text: 'An error occurred during the update. Please try again later.',
        confirmButtonText: 'OK'
      });
    });
  }
}