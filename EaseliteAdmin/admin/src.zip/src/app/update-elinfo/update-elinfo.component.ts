import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdmELInfo } from '../Class';
import { WebService } from '../Service';
import Swal from 'sweetalert2'; // Import SweetAlert2

@Component({
  selector: 'app-update-elinfo',
  templateUrl: './update-elinfo.component.html',
  styleUrls: ['./update-elinfo.component.scss']
})
export class UpdateElinfoComponent implements OnInit {

  admELInfo: AdmELInfo;
  AdmELInfoId: any;
  filesToUpload: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private service: WebService
  ) {
    this.admELInfo = new AdmELInfo();

    this.route.params.subscribe(params => {
      this.AdmELInfoId = params['AdmELInfoId'];

      // Fetch details of the ELInfo by ID
      this.service.GetAdmELInfoById(this.AdmELInfoId).subscribe(result => {
        this.admELInfo = result;
      });
    });
  }

  ngOnInit(): void {
    // No implementation required; can be removed or filled if needed
  }

  onUpdate() {
    // Update the subscription details
    this.service.UpdateAdmELInfo(this.admELInfo).subscribe(result => {
      if (result == 0) {
        Swal.fire({
          title: 'Error!',
          text: 'Something went wrong! Please try again.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      } else {
        Swal.fire({
          title: 'Success!',
          text: 'Updated Successfully.',
          icon: 'success',
          confirmButtonText: 'OK'
        }).then(() => {
          this.router.navigate(['/elinfolist']);
        });
      }
    });
  }

  isSidebarOpen = false;  // Variable to control sidebar visibility
  dropdownOpen: string | null = null; // Variable to control dropdown visibility

  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
  }

  toggleDropdown(section: string) {
    // Toggle dropdown visibility for the clicked section
    this.dropdownOpen = this.dropdownOpen === section ? null : section;
  }

  selectRole(role: string, route: string) {
    console.log(`Role selected: ${role}`);
    this.router.navigate([route]);
  }

  logout() {
    this.router.navigate(['/login']);
  }
}
