export const GlobalVariable = Object({
    SERVICE_API_URL:        'http://localhost:58029/api/',
    BASE_API_URL:        'http://localhost:58029/',
      });
    