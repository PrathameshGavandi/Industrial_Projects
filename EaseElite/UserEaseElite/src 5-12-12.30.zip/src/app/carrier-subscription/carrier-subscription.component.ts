import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalVariable } from '../Global';
import { WebService } from '../Service';

@Component({
  selector: 'app-carrier-subscription',
  templateUrl: './carrier-subscription.component.html',
  styleUrls: ['./carrier-subscription.component.scss']
})
export class CarrierSubscriptionComponent {

  fftSubscriptionList: any[] = [];
  FttPurchasePlan: any[] = [];
   UId: any;
   imgPath: string = GlobalVariable.BASE_API_URL;
isAnyPlanPurchased: any;
 
   constructor(
     private router: Router,
     private http: HttpClient,
     private service: WebService
   ) {}
 
   ngOnInit(): void {
     this.UId = JSON.parse(sessionStorage.getItem('SID'));
 
     // Fetch purchased plans first, then load subscription list
     this.fetchPurchasedPlans().then(() => {
       this.loadSubscriptionList();
     });
     // this.loadSubscriptionList();
   }
 
   // Load all subscription plans and set 'isPurchased' status
   private loadSubscriptionList(): void {
     this.service.GetAllAdmCarrierSubscription().subscribe((subscriptions) => {
       this. fftSubscriptionList = subscriptions.map((subscription) => {
         subscription.isPurchased = this.isPlanPurchased(subscription.FttSubscriptionId);
         return subscription;
       });
       console.log(this. fftSubscriptionList, "admSubscriptionList");
     });
   }
 
   // Fetch purchased plans and return a promise
   private fetchPurchasedPlans(): Promise<void> {
     return new Promise((resolve) => {
       this.service.GetAllCarrierPurchasePlan().subscribe((plans) => {
         this.FttPurchasePlan = plans;
         console.log("purchasedPlans",this.FttPurchasePlan, );
         resolve();
       });
     });
   }
 
   // Check if a plan is already purchased for this user
   private isPlanPurchased(subscriptionId: number): boolean {
     // Check if FttPurchasePlan is a valid array before using .some()
     return Array.isArray(this.FttPurchasePlan) && this.FttPurchasePlan.some(
       (plan) => plan.FttSubscriptionId === subscriptionId && plan.RegistrationId === this.UId
     );
   }
 
   // Handle the "Buy Now" button click
   onClick(subscriptionId: number): void {
     if (!this.isPlanPurchased(subscriptionId)) {
       this.router.navigateByUrl("/Carrierpaymentdetail/" + subscriptionId);
       console.log("sub id id ", subscriptionId);
       
     }
   }
 }