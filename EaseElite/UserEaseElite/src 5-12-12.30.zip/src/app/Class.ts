export class Registration {
    RegistrationId: number;
    FName: string;
    LName: string;
    Email: string;
    Password: string;
    confirmPassword:string;
    EmailStatus: string;
    OTPNo: string;
    DefaultRole: string;
    Status: string;
    CreatedBy: string;
    CreatedDate: string;
    UpdatedBy: string;
    UpdatedDate: string;
    Role: string;
    // Role: any;
}
export class FlightDetailsCompanion {
    DetailsId: number;
    name: string;
    flightNumber: number;
    date: string;
    time: string;
    from: string;
    to: string;
    ticket: string;
    CreatedBy: string;
    CreatedDate: string;
    UpdatedDate: string;
    UpdatedBy: string;
}
export class FlightDetailsFirsttimeTraveller {
    DetailsId: number;
    // name: string;
    flightNumber: number;
    date: string;
    time: string;
    from: string;
    to: string;
    ticket: string;
    // Proofid: string;
    CreatedBy: string;
    CreatedDate: string;
    UpdatedDate: string;
    UpdatedBy: string;
}
export class Companiondetails {
    DetailsId: number;
    // name: string;
    flightNumber: number;
    date: string;
    time: string;
    from: string;
    to: string;
    ticket: string;
    // Proofid: string;
    CreatedBy: string;
    CreatedDate: string;
    UpdatedDate: string;
    UpdatedBy: string;
}


export class PackageSenderDetails {
    // name: string;
    flightNumber: string;
    date: string;
    time: string;
    from: string;
    to: string;
    weight: number;
}
export class Carrierdetail{
    CarrierdetailId:Number;
    // name: String;
    flightNumber:String;
    date: String;
    time: String;
    from: String;
    to: String;
    kg:String;
    message:String;
    CreatedBy:String;
      CreatedDate:String;
      UpdatedBy:string;
      UpdatedDate:String;
  RegistrationId: any;
  To1: any;
  From1: any;
    
  }
  export class PaymentDetail{
    PaymentId:Number;
    Name: String;
    Email:String;
    Amount: String;
    // PaymentDate: String;
   
    CreatedBy:String;
      CreatedDate:String;
      UpdatedBy:string;
      UpdatedDate:String;
  }

  export class Login {
    LoginId: number;
    Email: String;
    Password: String;
    Role: String;
}
export class FttRequest {
    Id: number;
    Name: String;
    Date: String;
    Time: String;
    Destination: String;
    CreatedBy: String;
    CreatedDate: String;
    UpdatedBy: string;
    UpdatedDate: String;
}
export class Kyc {
    Id: number;
    Name: String;
    Email: string;
    Contact: string;
    PanCard: string;
    Address: string;
    CreatedBy: String;
    CreatedDate: String;
    UpdatedBy: string;
    UpdatedDate: String;

}
export class UserProfile{
    UserProfileId: number;
    registration: Registration
    RegistrationId: number;
    ContactNumber: string;
    Image: string;
    AlternativeEmail: string;
    Address: string;
    Country: string;
    Province: string;
    City: string;
    PostalCode: string;
    Status: string;
    Passport: string;
    AddressProof: string;
    KycStatus: string;
    CreatedDate: string;
    CreatedBy: string;
    UpdatedDate: string;
    UpdatedBy: string;
  KycCompleted: any;
    }
    

    
    export class FttSubscription{
        FttSubscriptionId: number;
        Title: string;
        SubTitle: string;
        Description: string;
        Price: string;
        PlanPeriod: string;
        Status: string;
        CreatedDate: string;
        CreatedBy: string;
        UpdatedDate: string;
        UpdatedBy: string;
        }
        export class FttTransactionDetail{
        FttTransactionDetailId: number;
        registration: Registration
        RegistrationId: number;
        fttSubscription: FttSubscription
        FttSubscriptionId: number;
        TransactionId: string;
        TransactionDate: string;
        TransactionStatus: string;
        TransactionAmount: string;
        Status: string;
        CreatedDate: string;
        CreatedBy: string;
        UpdatedDate: string;
        UpdatedBy: string;
        }
        export class FttPurchasePlan{
        FttPurchasePlanId: number;
        fttSubscription: FttSubscription
        FttSubscriptionId: number;
        registration: Registration
        RegistrationId: number;
        OfferedFor: string;
        NextRenewalDate: string;
        Status: string;
        CreatedBy: string;
        CreatedDate: string;
        UpdatedDate: string;
        UpdatedBy: string;
        }
        export class CompanionTransactionDetail{
            CompanionTransactionDetailId: number;
            RegistrationId: number;
            CompanionSubscriptionId: number;
            TransactionId: string;
            TransactionDate: string;
            TransactionStatus: string;
            TransactionAmount: string;
            Status: string;
            CreatedDate: string;
            CreatedBy: string;
            UpdatedDate: string;
            UpdatedBy: string;
            }
            export class CarrierTransactionDetail{
            CarrierTransactionDetailId: number;
            RegistrationId: number;
            CarrierSubscriptionId: number;
            TransactionId: string;
            TransactionDate: string;
            TransactionStatus: string;
            TransactionAmount: string;
            Status: string;
            CreatedDate: string;
            CreatedBy: string;
            UpdatedDate: string;
            UpdatedBy: string;
            }
            export class PackageSenderTransactionDetail{
            PackageSenderTansactionDetailId: number;
            RegistrationId: number;
            PackageSenderSubscriptionId: number;
            TransactionId: string;
            TransactionDate: string;
            TransactionStatus: string;
            TransactionAmount: string;
            Status: string;
            CreatedDate: string;
            CreatedBy: string;
            UpdatedDate: string;
            UpdatedBy: string;
            }
            export class CompanionPurchasePlan{
            CompanionPurchasePlanId: number;
            CompanionSubscriptionId: number;
            RegistrationId: number;
            OfferedFor: string;
            NextRenewalDate: string;
            Status: string;
            CreatedBy: string;
            CreatedDate: string;
            UpdatedDate: string;
            UpdatedBy: string;
            }
            export class CarrierPurchasePlan{
            CarrierPurchasePlanId: number;
            CarrierSubscriptionId: number;
            RegistrationId: number;
            OfferedFor: string;
            NextRenewalDate: string;
            Status: string;
            CreatedBy: string;
            CreatedDate: string;
            UpdatedDate: string;
            UpdatedBy: string;
            }
            export class PackageSenderPurchasePlan{
            PackageSenderPurchasePlanId: number;
            PackageSenderSubscriptionId: number;
            RegistrationId: number;
            OfferedFor: string;
            NextRenewalDate: string;
            Status: string;
            CreatedBy: string;
            CreatedDate: string;
            UpdatedDate: string;
            UpdatedBy: string;
            }
            

            export class AdmCarrierSubscription{
                AdmCarrierSubscriptionld  : number;
                Title: string;
                SubTitle: string;
                Description: string;
                Price: string;
                PlanPeriod: string;
                Status: string;
                CreatedDate: string;
                CreatedBy: string;
                UpdatedDate: string;
                UpdatedBy: string;
            
                }
                export class AdmCompSubscription{
                AdmCompSubscriptionld : number;
                Title: string;
                SubTitle: string;
                Description: string;
                Price: string;
                PlanPeriod: string;
                Status: string;
                CreatedDate: string;
                CreatedBy: string;
                UpdatedDate: string;
                UpdatedBy: string;
                }


                export class AdmSenderSubscription{
                    AdmSenderSubscriptionld : number;
                    Title: string;
                    SubTitle: string;
                    Description: string;
                    Price: string;
                    PlanPeriod: string;
                    Status: string;
                    CreatedDate: string;
                    CreatedBy: string;
                    UpdatedDate: string;
                    UpdatedBy: string;
                    }

                    export class UserRole{
                        UserRoleId: number;
                        RoleId: number;
                        RegistrationId: number;
                        Status: string;
                        CreatedDate: string;
                        CreatedBy: string;
                        UpdatedDate: string;
                        UpdatedBy: string;
                        }
                        


                        export class CompanionDetail{
                            CompanionId: number;
                            registration: Registration
                            RegistrationId: number;
                            FlightNumber: string;
                            Date: string;
                            Time: string;
                            From1: string;
                            To1: string;
                            UploadTicket: string;
                            CreatedDate: string;
                            CreatedBy: string;
                            UpdatedDate: string;
                            UpdatedBy: string;
                            }
                            export class FttDetail{
                            FttId: number;
                            registration: Registration
                            RegistrationId: number;
                            FlightNumber: string;
                            Date: string;
                            Time: string;
                            From1: string;
                            To1: string;
                            UploadTicket: string;
                            CreatedDate: string;
                            CreatedBy: string;
                            UpdatedDate: string;
                            UpdatedBy: string;
                            }


             

             export class MakeRequest{
                MakeRequestId: number;
                registration: Registration
                RegistrationId: number;
                TicketId: number;
                Status: string;
                CompAgree: string;
                FttAgree: string;
                TicketStatus: string;
                Feedback: string;
                Txt: string;
                CreatedDate: string;
                CreatedBy: string;
                UpdatedDate: string;
                UpdatedBy: string;
                }
                


                export class CarrierDetail{
                    CarrierDetailId: number;
                    registration: Registration
                    RegistrationId: number;
                    FlightNumber: string;
                    Date: string;
                    Time: string;
                    From1: string;
                    To1: string;
                    LoadCapacity: string;
                    Instrauction: string;
                    Status: string;
                    CreatedDate: string;
                    CreatedBy: string;
                    UpdatedDate: string;
                    }
                    export class PackageDetail{
                    PackageDetailId: number;
                    registration: Registration
                    RegistrationId: number;
                    FlightNumber: string;
                    Date: string;
                    Time: string;
                    From1: string;
                    To1: string;
                    LoadCapacity: string;
                    Status: string;
                    CreatedDate: string;
                    CreatedBy: string;
                    UpdatedDate: string;
                    UpdatedBy: string;
                      UploadTicket: string;
                    }
                    



                    export class Feedback{
                        FeedbackId: number;
                        registration: Registration
                        RegistrationId: number;
                        Description: string;
                        CreatedDate: string;
                        CreatedBy: string;
                        UpdatedDate: string;
                        UpdatedBy: string;
                        
                        }
                    