import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SenderDetailChackoutComponent } from './sender-detail-chackout.component';

describe('SenderDetailChackoutComponent', () => {
  let component: SenderDetailChackoutComponent;
  let fixture: ComponentFixture<SenderDetailChackoutComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SenderDetailChackoutComponent]
    });
    fixture = TestBed.createComponent(SenderDetailChackoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
