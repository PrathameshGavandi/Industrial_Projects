import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Registration } from '../Class';
import { WebService } from '../Service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent {
  registration: Registration;

  mainList: any;
  demo: any;
  Id: any;


  showPassword: boolean = false;
  showConfirmPassword: boolean = false;

  // New password and confirm password values
  newPassword: string = '';
  confirmPassword: string = '';


  passwordVisible: boolean = false;
  constructor(private router: Router, private http: HttpClient,
    private service: WebService, private route: ActivatedRoute,) {

    this.registration = new Registration();

    this.mainList = [];
    this.demo = 0;
    

    this.route.params.subscribe((params) => {
      debugger
      this.Id = params['Id'];
      console.log("addclient", this.Id)

      this.service.GetRegistrationById(this.Id).subscribe((result) => {

        this.registration = result;
        console.log("this.registration", this.registration);

      });

    });

  }




  // Toggle password visibility for both fields
  togglePasswordVisibility(type: string) {
    if (type === 'newPassword') {
      this.showPassword = !this.showPassword;
    } else if (type === 'confirmPassword') {
      this.showConfirmPassword = !this.showConfirmPassword;
    }
  }
  OnSubmit() {
    console.log(this.newPassword, "this.newPassword");
    console.log(this.confirmPassword, "this.confirmPassword");
    
    if (this.newPassword === this.confirmPassword) {
      console.log("final", this.registration);
      this.registration.Password = this.newPassword;
  
      this.service.UpdateRegistration(this.registration).subscribe((result) => {
        console.log("password", result);
        if (result === 0) {
          Swal.fire({
            title: 'Error!',
            text: 'Something went wrong! Please try again.',
            icon: 'error',
            confirmButtonText: 'OK'
          });
        } else {
          Swal.fire({
            title: 'Success!',
            text: 'Password changed successfully.',
            icon: 'success',
          
          });
          // Redirect to login page
          this.router.navigate(['/login']);
          
        }
      });
    } else {
      Swal.fire({
        title: 'Error!',
        text: 'Passwords do not match.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    }
  }
  

}