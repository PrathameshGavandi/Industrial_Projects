import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { Registration } from '../Class';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';
import Swal from 'sweetalert2';  // Import SweetAlert2

@Component({
  selector: 'app-verify-email',
  templateUrl: './verify-email.component.html',
  styleUrls: ['./verify-email.component.scss']
})
export class VerifyEmailComponent {

  @ViewChild('input1') input1!: ElementRef;
  @ViewChild('input2') input2!: ElementRef;
  @ViewChild('input3') input3!: ElementRef;
  @ViewChild('input4') input4!: ElementRef;
  @ViewChild('input5') input5!: ElementRef;
  @ViewChild('input6') input6!: ElementRef;

  Id: any;
  registration: Registration;
  Registrationlist: any[] = [];
  mainList: any[] = [];
  otp1: string = '';
  otp2: string = '';
  otp3: string = '';
  otp4: string = '';
  otp5: string = '';
  otp6: string = '';
  receivedOtp: string = ''; // For storing the backend OTP

  constructor(
    private renderer: Renderer2,
    private router: Router,
    private http: HttpClient,
    private route: ActivatedRoute,
    private service: WebService
  ) {
    this.registration = new Registration();

    // Retrieve ID from route parameters
    this.route.params.subscribe((params) => {
      this.Id = params['Id'];
      console.log("Received ID:", this.Id);

      // Fetch registration details by ID
      this.service.GetRegistrationById(this.Id).subscribe((result) => {
        this.registration = result;
        console.log("Fetched registration:", this.registration);

        // Send OTP when component loads
        this.SendOTPEmail();
      });
    });
  }

  moveToNext(currentInput: any, nextInput: any): void {
    if (currentInput.value.length === 1 && nextInput) {
      nextInput.focus();
    }
  }

  OnSubmit1(): void {
    // Combine entered OTP fields
    const enteredOtp = 
      (this.otp1 || '').toString() + 
      (this.otp2 || '').toString() + 
      (this.otp3 || '').toString() + 
      (this.otp4 || '').toString() + 
      (this.otp5 || '').toString() + 
      (this.otp6 || '').toString();

    console.log("Entered OTP:", enteredOtp);
    console.log("Received OTP from backend:", this.receivedOtp);

    // Validate OTP length
    if (enteredOtp.length < 6) {
      Swal.fire('Validation Error', 'Please enter all 6 digits of the OTP.', 'error');
      return;
    }

    // Compare entered OTP with the backend OTP
    if (this.receivedOtp === enteredOtp) {
      // Swal.fire('Success', 'OTP Matched!', 'success');

      // Update email status to active
      this.registration.EmailStatus = "Active";
      this.service.UpdateRegistration(this.registration).subscribe((updateResult) => {
        if (updateResult === 0) {
          Swal.fire('Error', 'Email activation failed!', 'error');
        } else {
          Swal.fire('Success', 'Email activated successfully!', 'success');
          this.router.navigate(['/login']);
        }
      });
    } else {
      Swal.fire('Error', 'OTP not matched! Please try again.', 'error');
    }
  }
  // confirmResendOTP() {
  //   // Show SweetAlert confirmation dialog
  //   Swal.fire({
  //     title: 'Are you sure?',
  //     text: 'Do you want to resend the OTP to your registered email?',
  //     icon: 'warning',
  //     showCancelButton: true,
  //     confirmButtonColor: '#3085d6',
  //     cancelButtonColor: '#d33',
  //     confirmButtonText: 'Yes, resend OTP!'
  //   }).then((result) => {
  //     if (result.isConfirmed) {
  //       // Call method to send OTP
  //       this.SendOTPEmail();
  //     } else {
  //       // Log cancellation (optional)
  //       console.log('User canceled OTP resend');
  //     }
  //   });
  // }

  SendOTPEmail(): void {
    if (!this.registration.Email) {
      Swal.fire('Error', 'Email is not available!', 'error');
      return;
    }

    this.service.SendOTPEmail(this.registration.Email).subscribe({
      next: (response) => {
        // Swal.fire('Success', 'OTP sent successfully!', 'success');
        console.log('Email sent successfully:', response);
        Swal.fire({
          icon: 'success',
          title: 'Success!',
          text: 'The  OTP has been successfully.',
          timer: 2000, // Optional: the alert will automatically close after 2 seconds
          showConfirmButton: false // Optional: hides the "OK" button
        });




        // Save OTP received from backend for comparison
        this.receivedOtp = response.otp.toString();
        console.log('Received OTP:', this.receivedOtp);
      },
      error: (err) => {
        console.error("Error while sending OTP:", err);
        Swal.fire('Error', 'Failed to send OTP. Please try again later.', 'error');
      }
    });
    
  }
  
}
