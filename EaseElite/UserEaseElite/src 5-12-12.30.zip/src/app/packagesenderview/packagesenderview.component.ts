import { Component } from '@angular/core';

@Component({
  selector: 'app-packagesenderview',
  templateUrl: './packagesenderview.component.html',
  styleUrls: ['./packagesenderview.component.scss']
})
export class PackagesenderviewComponent {

}
