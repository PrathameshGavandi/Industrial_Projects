import { Component } from '@angular/core';

@Component({
  selector: 'app-carrierview',
  templateUrl: './carrierview.component.html',
  styleUrls: ['./carrierview.component.scss']
})
export class CarrierviewComponent {

}
