import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserProfile, Registration, MakeRequest } from '../Class';
import { GlobalVariable } from '../Global';
import { WebService } from '../Service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent {
  id;
  imgPath: string = GlobalVariable.BASE_API_URL;
  MakereqID;
  userprofile = new UserProfile();
registration = new Registration();
  allRegistration: Registration[];
  CompanionsList: any;
  SID: string;
  FttId
  FttDetailList:any ;
  filteredRequests :any
  showPopup: boolean = false;
  MakeRequest:any
  requestDetail: MakeRequest;
  // FttDetailList:any ;
  makerequest:MakeRequest
  myCompanionId: number;

  fttId
  mycmpId



  constructor(private route: ActivatedRoute,private router: Router, private http: HttpClient, private service: WebService) {
  
    this.registration = new Registration();
    this.userprofile.registration = new Registration();
    this.makerequest=new MakeRequest()
    this.requestDetail=new MakeRequest();
    this.requestDetail.registration = new Registration

    this.route.paramMap.subscribe(params => {
      this.FttId = +params.get('FttId')!; // Use "+" to convert string to number
      console.log('FttId ID:', this.FttId);
    });
    
   this.id= sessionStorage.getItem('SID');
   console.log(" My ID",this.id);
  
  

   this.route.params.subscribe(params => {
    this.fttId = params['FttId']; // From the route
  });
  
  this.route.queryParams.subscribe(queryParams => {
   this. mycmpId = queryParams['myFttId']; // From the query parameters
  });
   
   
  }
  openPopup() {
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }


  ngOnInit(): void {
    this.SID = sessionStorage.getItem('SID');
    this.GetInfo();

    this. GetAllFttDetail();
    }


  GetAllFttDetail(): void {

    this.service.GetFttDetailById(this.FttId).subscribe((result) => {
      this.FttDetailList=result
      console.log("Ftt  Info by id ",this.FttDetailList);
     
        });
      }

  

  GetInfo(){
 
    this.service.GetRegistrationById(this.id).subscribe((result) => {
     this.registration=result
     console.log("Registration  Info",result);
    
       });

   
      this.service.GetUserProfileById(this.id).subscribe((result) => {
        this.userprofile=result
        console.log("User Info",result);
       
          });

      }

// requestAccept(){

//   console.log("my ftt id is ",this.FttDetailList.FttId);
  
//   console.log("my ftt id is ");



//   // this.service.GetRegistrationById().subscribe((result) => {
//   //   this.registration=result
//   //   console.log("Registration  Info",result);
   
//   //     });

// }

// requestAccept() {
//   console.log('Accept Request button clicked!');
//   console.log("my ftt Tikit id  is ",this.FttDetailList.FttId);



//   this.service.GetAllMakeRequest().subscribe((result) => {
//     this.MakeRequest = result;

//     // Filter MakeRequest where TicketId matches FttId in FttDetailList
//     this.filteredRequests = result.filter(ftt => ftt.TicketId === this.FttDetailList.FttId);

//     console.log(this.filteredRequests);
    
//     // Assuming you want the MakeRequestId from the first match
//     if (this.filteredRequests.length > 0) {
//       this.MakereqID = this.filteredRequests[0].MakeRequestId; // Get the MakeRequestId of the first matched item
//       console.log(this.MakereqID);
//     } else {
//       console.log("No matching requests found");
//     }
    

    
//     this.service.GetMakeRequestById(this.MakereqID).subscribe((result) => {
//       this.makerequest=result
     
//       this.makerequest.CompAgree="Active"
//       console.log(this.makerequest);
  
//       this.service.UpdateMakeRequest( this.makerequest).subscribe(
//         (updateResult) => {
//           console.log('MakeRequest updated successfully:', updateResult);
//           // Handle success response, e.g., show a success message
//         },
//         (error) => {
//           console.error('Error updating profile:', error);
//           // Handle error, e.g., show an error message
//         }
//       );


//         });
 
    
//   });
  

// }



submitRequest() {


  this.requestDetail.registration.RegistrationId=this.id ;
  this.requestDetail.TicketId= this.mycmpId
  this.requestDetail.Status="Active";
  this.requestDetail.CompAgree="Yes";
  this.requestDetail.FttAgree="";
  this.requestDetail.TicketStatus=""
  this.requestDetail.Feedback="";
    this.requestDetail.CreatedBy="";


    console.log('Request Submitted:', this.requestDetail);


    this.service.AddMakeRequest(this.requestDetail).subscribe(
      (result) => {
        if (result > 0) {
        }
        else{

        }
        });

    this.showPopup = false;

}

}