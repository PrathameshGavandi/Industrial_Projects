import { Component } from '@angular/core';
import { Registration, UserProfile } from '../Class';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { WebService } from '../Service';
import Swal from 'sweetalert2';
// import { SocialAuthService } from '@abacritt/angularx-social-login/socialauth.service';
import { SocialAuthService } from "@abacritt/angularx-social-login";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

    user: any
    userprofile=new UserProfile();

  registration: Registration;
  submitted: boolean = false;
  passwordVisible: boolean = false;
  myRegistrationId: any;
  myresult: any;
//   abc:any=1;

role 
mainlist: any[] = []
registrationList: any[] = []
emailStatus: any
registrationId: any
defaultRole: any
userid: any

loggedIn: any
newId:any


  constructor( private authService: SocialAuthService,private router: Router, private http: HttpClient, private service: WebService) {
    this.registration = new Registration();
    this.registration = new Registration();
    this.userprofile.registration = new Registration();
    // this.registration.Role = '1'; // Default role option
  }

  togglePasswordVisibility() {
    this.passwordVisible = !this.passwordVisible;
  }

  onRoleChange(event: any) {
    const selectedRole = event.target.value;
    console.log("Role selected:", selectedRole);  // Debugging
    this.role = selectedRole;
  }

  OnSubmit() {
  
    console.log(this.registration); // Debugging: Check what role is being submitted

    this.service.Login(this.registration.Email, this.registration.Password).subscribe((result) => {
        console.log("my ID is ", result.RegistrationId);
        this.myRegistrationId = result.RegistrationId;

        if (result.RegistrationId == 0) {
            // If login fails, show an error alert
            Swal.fire({
                icon: 'error',
                title: 'Invalid Email or Password',
                text: 'Please check your login credentials and try again.',
                confirmButtonText: 'Okay'
            });
        } else {
            sessionStorage.setItem('SID', result.RegistrationId);

            this.service.GetRegistrationById(this.myRegistrationId).subscribe((result) => {
                this.myresult = result;
                console.log("Registration Detail", result);

                // if (this.myresult ) {
                //     console.log("Selected Role:", this.registration.DefaultRole);
                //     console.log("Default Role from backend:", this.myresult.DefaultRole);

                    if (this.role) {
                      Swal.fire({
                        icon: 'success',
                        title: 'Login successful!',
                        text: 'You will be redirected shortly.',
                        timer: 2000,
                        showConfirmButton: false
                      }).then(() => {
                        // Switch based on the role
                        switch (this.role) {
                          case "1":
                            this.router.navigate(['/fttpanel']); // Redirect to FTT Panel
                            break;
                          case "2":
                            this.router.navigate(['/companionpanel']); // Redirect to Companion Panel
                            break;
                          case "3":
                            this.router.navigate(['/carrierpanel']); // Redirect to Carrier Panel
                            break;
                          case "4":
                            this.router.navigate(['/packagesenderrpanel']); // Redirect to Package Sender Panel
                            break;
                          default:
                            // Log an error for an invalid role if no case matches
                            console.error("Invalid role:", this.role);
                            break;
                        }
                      });
                    }
                    
                     else {
                      
                    }
                // } else {
                //     console.error("No DefaultRole found in the response.");
                // }
            }, (error) => {
                console.error("Error fetching registration details:", error);
            });
        }
    }, (error) => {
        console.error("Login error:", error);
        Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            text: 'There was an issue with the login. Please try again later.',
            confirmButtonText: 'Okay'
        });
    });

    this.submitted = true;
  }







  ngOnInit() {
 
    this.userid = JSON.parse(sessionStorage.getItem('SID'));
    if (this.userid == 0) {
      // alert("Invalid Email and Password.")
      // alert('Invalid Email or Password.');
    }
    else {
      // alert("Login Successfully");
      // this.showSuccessAlert() ;
    //   this.router.navigateByUrl("/UserDashbord") ;
    }

    ////////////////////////////////////////////////////////////////////////
    this.authService.authState.subscribe((user) => {
      this.user = user;
      this.loggedIn = (user != null);
      console.log("this.user", this.user)

    //   this.router.navigateByUrl("/fttpanel");

      this.service.GetAllRegistration().subscribe((result) => {
        this.mainlist = []
        this.registrationList = []
        for (let data of result) {
          this.registrationList.push(data);
        }
        this.mainlist = this.registrationList.filter(x => x.Email == this.user.email);


        if (this.mainlist.length == 0) {
          //mail not exist then Add new record
          this.registration.FName = this.user.firstName
          this.registration.LName = this.user.lastName

          this.registration.Email = this.user.email
          this.registration.OTPNo = ""
          this.registration.Password = ""
          this.registration.EmailStatus = "Active"
          this.registration.Status = "Active"
          this.registration.DefaultRole='1'
          

          this.service.AddRegistration(this.registration).subscribe((result) => {
            if (result > 0) {
              // alert('Signup Successfully.');
              Swal.fire({
                title: 'Signup Successful!',
                text: 'You have successfully signed up. Welcome aboard!',
                icon: 'success',
                confirmButtonText: 'OK'
              });

            //   this.showSuccessAlert4()
              sessionStorage.setItem('SID',result)
            //   this.router.navigateByUrl("/fttpanel");
             this.router.navigate(['/fttpanel']);
              //======================================================================================================
    // Prepare user profile data
    this.userprofile.registration.RegistrationId = result; // Fix assignment
    this.userprofile.ContactNumber = "";
    this.userprofile.Address = "";
    this.userprofile.AlternativeEmail = "";
    this.userprofile.Country = "";
    this.userprofile.Province = "";
    this.userprofile.City = "";
    this.userprofile.Image = "123.jpg";
    this.userprofile.PostalCode = "";
    this.userprofile.Passport = "";
    this.userprofile.AddressProof = "";
    this.userprofile.KycStatus = "";
    this.userprofile.Status = "Active";

    console.log("user profile", this.userprofile);
    
    // Add user profile
    this.service.AddUserProfile(this.userprofile).subscribe(result => {
      if (result > 0) {
        // Swal.fire('Success', 'OTP has been sent to your email. Please check your inbox to proceed.', 'success');
      } else {
        Swal.fire('Error', 'Error OTP has been sent to your email.', 'error');
      }
    });
// // //=======================================================================================================

                 //Add Default user Role as a EndUser

            // this.userRole.RegistrationId=result
            // this.userRole.RoleId=2
            // // this.userRole.AdmRoleMasterId=2
            // this.userRole.Status="InActive"
            // this.service.AddUserRole(this.userRole).subscribe((result) => {
            //   if (result > 0) {
            //     // alert('add user Role Successfully.');
            //     this.router.navigateByUrl("/UserDashbord");

            //   }
            //   else {
            //     alert("Something went wrong! Please try again.")
            //     // this.showSuccessAlert3()
            //   }
            // });

            }
            else {
              Swal.fire({
                title: 'Something went wrong!',
                text: 'Please try again.',
                icon: 'error',
                confirmButtonText: 'OK'
              });
              
              // alert("Something went wrong! Please try again.")
            //   this.showSuccessAlert3()
            }
          });
        }
        else {
          
          
          this.service.GetRegistrationByEmail(this.user.email).subscribe((result) => {
            this.registration = result; 
            this.newId = this.registration.RegistrationId
            sessionStorage.setItem('SID', this.newId);
            this.userid = JSON.parse(sessionStorage.getItem('SID'));
            console.log( "userid", this.userid);
            this.router.navigate(['/fttpanel']);
            if (this.userid == 0) {
              alert("Something went wrong! Please try again.");
            //   this.showSuccessAlert3()


            }
           
          })



        }
      })

    });
  }








}
