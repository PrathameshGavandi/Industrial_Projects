import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserProfile, Registration } from '../Class';
import { GlobalVariable } from '../Global';
import { WebService } from '../Service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  id;
  imgPath: string = GlobalVariable.BASE_API_URL;

  userprofile = new UserProfile();
registration = new Registration();

  constructor(private router: Router, private http: HttpClient, private service: WebService) {
  
    this.registration = new Registration();
    this.userprofile.registration = new Registration();


    
   this.id= sessionStorage.getItem('SID');
   console.log(" My ID",this.id);
  
   
  }

  logout() {
    // Clear session storage
    sessionStorage.clear();
    localStorage.clear();
    this.router.navigate(['/login']).then(() => {
      window.location.reload(); // Force reload to ensure that the login page is displayed fresh
    });
  }

  ngOnInit(): void {
 
    this.GetInfo();
    }
  

  GetInfo(){
 
    this.service.GetRegistrationById(this.id).subscribe((result) => {
     this.registration=result
     console.log("Registration  Info",result);
    
       });

   
      this.service.GetUserProfileById(this.id).subscribe((result) => {
        this.userprofile=result
        console.log("User Info",result);
       
          });

      }
}
