import { Component, OnInit } from '@angular/core';
import { CompanionDetail, Companiondetails, FttDetail, Registration } from '../Class';
import { AirportService } from '../airport.service';
import Swal from 'sweetalert2';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { WebService } from '../Service';

@Component({
  selector: 'app-companion-details',
  templateUrl: './companion-details.component.html',
  styleUrls: ['./companion-details.component.scss']
})
export class CompanionDetailsComponent implements OnInit {


  activeAccordion: number | null = null;
  fttDetail: FttDetail;
  CompanionsList: any;
 FttList: any;
 filteredFtt: any[] = []; // Filtered list based on dropdown selection
 anotherList: any[] = []; // Example list to compare with
 selectedFtt
 Rlist:any[]=[]
 mycmpid
 userprofile1: Registration;
  companionDetail: CompanionDetail;
  searchTermFrom: string = '';
  filteredAirportsFrom: any[] = [];
  isDropdownOpenFrom: boolean = false;
  searchTermTo: string = '';
  filteredAirportsTo: any[] = [];
  isDropdownOpenTo: boolean = false;
  
  airports: any[] = [];
  selectedAirportFrom: any = null;
  selectedAirportTo: any = null;
  submittedFlightDetails: any = null;
 
 SID:any;
  flightdetails: any;
  matchedUsers: any;
  cmpList: any;
  filesToUpload: any;
  minDate: string;
  userprofile: any;
  kycCompleted: boolean = false;
  id: any;
  registration: any;
  GetCompanionDetailById:any;
RequestList: any;

isAccordionOpen: any;
makerequest:any
AcceptList: any;

  constructor(private airportService: AirportService,private router: Router, private http: HttpClient, private service: WebService) {
    this.companionDetail = new CompanionDetail();
    
  }


  ngOnInit() {
    this. GetAllCompanionDetail();
    this.GetAllFftDetail();  
    this.SID = sessionStorage.getItem('SID');

    

    this.GetAllMakeRequest();
    // Fetch airport data
    
    // this.airportService.getAirports().subscribe((data: any[]) => {
    //   this.airports = data;
    // });
   
    
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0]; // Format as YYYY-MM-DD

    this.SID = sessionStorage.getItem('SID'); // Get the user session ID
    this.service.GetUserProfileById(this.SID).subscribe(result => {
      this.userprofile = result;

  
      // Check if KYC is approved for the user
      if (this.userprofile.KycStatus === 'Approve') {
        this.kycCompleted = true;
        // console.log("my kyc is " ,this.kycCompleted);
        
        // Swal.fire({
        //   icon: 'info',
        //   title: 'KYC Already Approved',
        //   text: 'Your KYC has been approved. Submission is disabled.',
        //   confirmButtonText: 'OK'
        // });
      }
    }); 

    this.airportService.getAirports().subscribe((data: any[]) => {
      this.airports = data;
 
    });

    this.service.GetAllRegistration().subscribe(
      (data) => {
       this.Rlist=data
       console.log("All Registration data is ", this.Rlist);
       
        });




    
  }

  
//   GetInfo(){
 
//     this.service.GetRegistrationById(this.id).subscribe((result) => {
//      this.registration=result
//      console.log("Registration  Info",result);
    
//        });

//       }

  GetAllCompanionDetail(): void {
    this.service.GetAllCompanionDetail().subscribe(data => {
      this.cmpList = data.filter(item => item.RegistrationId == this.SID );
      // this.cmpList = data;
 
      
      console.log("CompanionDetailList  is ", this.cmpList);
    }, (error) => {
      console.error('Error fetching fttdetailList:', error);
      Swal.fire({
        title: 'Error!',
        text: 'Failed to load fttdetailList. Please try again later.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    });
  }
  //============================================================
  GetAllFftDetail(): void {
    this.service.GetAllFttDetail().subscribe(
      (data) => {
        this.FttList =  data


        // = data.filter(item => item.RegistrationId ==this.SID );

        // this.FttList = data.filter(item => item.RegistrationId == this.SID );
        console.log('FttList Data is ', this.FttList);
      },
      (error) => {
        console.error('Error fetching FttList:', error);
        Swal.fire({
          title: 'Error!',
          text: 'Failed to load FttList. Please try again later.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    );
  }
 
  //======================================================================

  // Search for 'From' airport
  // onSearchFrom() {
  //   const searchTermLower = this.searchTermFrom.toLowerCase();
  //   this.filteredAirportsFrom = this.airports.filter(airport =>
  //     airport.city.toLowerCase().startsWith(searchTermLower)
  //   );
  //   this.isDropdownOpenFrom = this.filteredAirportsFrom.length > 0;
  // }

  // // Search for 'To' airport
  // onSearchTo() {
  //   const searchTermLower = this.searchTermTo.toLowerCase();
  //   this.filteredAirportsTo = this.airports.filter(airport =>
  //     airport.city.toLowerCase().startsWith(searchTermLower)
  //   );
  //   this.isDropdownOpenTo = this.filteredAirportsTo.length > 0;
  // }



  onSearchFrom() {
    const searchTermLower = this.searchTermFrom.toLowerCase();
    
    this.filteredAirportsFrom = this.airports
      .filter((airport) => airport.name.toLowerCase().startsWith(searchTermLower))
      .sort((a, b) => a.name.localeCompare(b.name)); // Sorting alphabetically
    
    this.isDropdownOpenFrom = this.filteredAirportsFrom.length > 0;
  }
  
  onSearchTo() {
    const searchTermLower = this.searchTermTo.toLowerCase();
    
    this.filteredAirportsTo = this.airports
      .filter((airport) => airport.name.toLowerCase().startsWith(searchTermLower))
      .sort((a, b) => a.name.localeCompare(b.name)); // Sorting alphabetically
    
    this.isDropdownOpenTo = this.filteredAirportsTo.length > 0;
  }
  

  // Select 'From' airport
  onSelectAirportFrom(airport: any) {
    this.selectedAirportFrom = airport;
    this.searchTermFrom = airport.name;
    this.companionDetail.From1 = airport.name;
    this.filteredAirportsFrom = [];
    this.isDropdownOpenFrom = false;
  }
  

  // Select 'To' airport
  onSelectAirportTo(airport: any) {
    this.selectedAirportTo = airport;
    this.searchTermTo = airport.name;
    this.companionDetail.To1 = airport.name;
    this.filteredAirportsTo = [];
    this.isDropdownOpenTo = false;
  }



  fileChangeEvent(fileInput: any): void {
    this.filesToUpload = <Array<File>>fileInput.target.files; // Cast file input to File array
    if (this.filesToUpload.length > 0) {
      this.companionDetail.UploadTicket = this.filesToUpload[0].name; // Store the file name in the object
    }
  }
  // Submit flight details
  onSubmit() {
    if (!this.kycCompleted) {
      // Show alert for incomplete KYC
      Swal.fire({
        title: 'KYC Incomplete',
        text: 'Please complete your KYC before submitting the form.',
        icon: 'warning',
        confirmButtonText: 'OK'
      }).then((result) => {
        if (result.isConfirmed) {
          // Redirect to KYC page
          this.router.navigate(['/kyc']);
        }
      });
  
  
  
  
      
    } else {
      // Check if the user's SID and role exist in the user role table
      this.service.GetAllUserRole().subscribe((Result) => {
        console.log(Result);
        const isValid = Result.some(
          (role) => role.RegistrationId == this.SID && role.RoleId == 3
        );
  
        if (isValid) {
          // If valid, proceed with form submission
          this.companionDetail.RegistrationId = this.SID;
          this.companionDetail.CreatedBy = "Active";
          console.log("AddFttDetail", this.companionDetail);
  
          this.service.AddCompanionDetail(this.companionDetail).subscribe((result) => {
            if (result > 0) {
              const formData = new FormData();
              formData.append('uploadedImage', this.filesToUpload[0], this.filesToUpload[0].name);
  
              // Save the uploaded image
              this.service.SaveCompanionDetailImage(formData, result).subscribe(() => {
                // Refresh the list of FTT details after submission
                const fttId = result;
                const index = this.FttList.findIndex((item) => item.FttId === fttId);
                if (index !== -1) {
                  this.onAccordionToggle(fttId, index);
                }
  
                this.GetAllCompanionDetail();
              });
            }
          });
        } else {
          // If not valid, redirect to purchase plan
          Swal.fire({
            title: 'Access Denied',
            text: 'Would you like to proceed with this amazing plan? Unlock premium features now!',
            icon: 'error',
            confirmButtonText: 'Yes, Proceed'
          }).then((result) => {
            if (result.isConfirmed) {
              this.router.navigate(['/companionsubscription']);
            }
          });
        }
      });
    }
  }
  
  
  

deleteFtt(id: number): void {
  Swal.fire({
    title: 'Are you sure?',
    text: 'You won’t be able to revert this!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      // Retrieve Ftt Detail by ID
      this.service.GetCompanionDetailById(id).subscribe({
        next: (fttDetail) => {
          if (!fttDetail) {
            Swal.fire({
              title: 'Error!',
              text: 'Record not found.',
              icon: 'error',
              confirmButtonText: 'Ok'
            });
            return;
          }

          // Update FttDetail Status to "InActive"
          const updatedFttDetail = { ...fttDetail, CreatedBy: 'InActive' };
          this.service.UpdateCompanionDetail(updatedFttDetail).subscribe({
            next: (updateResult) => {
              if (updateResult === 0) {
                Swal.fire({
                  title: 'Error!',
                  text: 'Could not delete the record. Please try again.',
                  icon: 'error',
                  confirmButtonText: 'Ok'
                });
              } else {
                Swal.fire(
                  'Deleted!',
                  'The record has been deleted successfully.',
                  'success'
                );
                // Refresh the list of Ftt Details
                this.GetCompanionDetailById(); // Call a separate function to reload the data
              }
            },
         
          });
        },
        error: (err) => {
          console.error('Error retrieving FttDetail:', err);
          Swal.fire({
            title: 'Error!',
            text:'Something went wrong while deleting. Please try again.',
            icon: 'error',
            confirmButtonText: 'Ok'
          });
        }
      });
    }
  });
}




  onAccordionToggle(cmpId: number, index: number): void {
    // Toggle active accordion
    if (this.activeAccordion === index) {
      this.activeAccordion = null; // Close if already open
      this.filteredFtt  = [];
    } else {
      this.activeAccordion = index; // Open the clicked accordion
      this.compareWithAnotherList(cmpId); // Fetch and filter data
    }
  }
  
  compareWithAnotherList(cmpId: number): void {
    console.log('Selected CMP ID:', cmpId);
    this.mycmpid =cmpId;
    const selectedCmpDetails = this.cmpList.find((ftt) => ftt.CompanionId == cmpId);
  
    console.log('Selected Cmp Details:', selectedCmpDetails);
  
    if (selectedCmpDetails) {
      // this.filteredFtt = (this.FttList || []).filter(
      //   (filteredFtt) =>
      //     filteredFtt.From1 == selectedFttDetails.From1 &&
      //     filteredFtt.To1 == selectedFttDetails.To1
      // );

      this.filteredFtt = this.FttList.filter(
        (companion) =>
          companion.From1 ==selectedCmpDetails.From1 &&
          companion.To1 == selectedCmpDetails.To1 &&
          companion.Date === selectedCmpDetails.Date 
      );
      console.log(this.filteredFtt );
      

    } else {
      this.filteredFtt = [];
    }
  
    console.log('Filtered Companions:', this.filteredFtt);
  }
  
  makeRequest(FttId: number): void {
    console.log('Make Request for Companion ID:', FttId);
  
    // Navigate to the companion view page with the ID
    // this.router.navigate(['/view', FttId]);

    this.router.navigate(['/view', FttId], { 
      queryParams: { myFttId: this.mycmpid } 
    });

    }

  getname(UId: number): string {
    const ResName = this.Rlist.filter(res => res.RegistrationId === UId);
  
    if (ResName.length > 0) {
      return `${ResName[0].FName} ${ResName[0].LName}`; // Concatenate FName and Lanem
    } else {
      return 'NoImageAvailable.png'; // Default value when no matching record is found
    }
  }

  formatDate(date: string): string {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(date).toLocaleDateString(undefined, options);
  }
  
  // Format Time
  formatTime(time: string): string {
    const [hour, minute] = time.split(':').map(Number);
    const isPM = hour >= 12;
    const formattedHour = hour % 12 || 12;
    return `${formattedHour}:${minute.toString().padStart(2, '0')} ${isPM ? 'PM' : 'AM'}`;
  }
  
  




  CancelRequest(requestId){
    this.service.GetMakeRequestById(requestId).subscribe(
      (result) => {
        this.makerequest = result;
        this.makerequest.CompAgree = "";
  
        // Display SweetAlert confirmation
        Swal.fire({
          title: 'Are you sure?',
          text: 'Do you want to Cancel this request?',
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, Cancel it!',
          cancelButtonText: 'No, cancel',
        }).then((response) => {
          if (response.isConfirmed) {
            // Proceed with updating the request
            this.service.UpdateMakeRequest(this.makerequest).subscribe(
              (updateResult) => {
                console.log('MakeRequest updated successfully:', updateResult);
  
                // Success SweetAlert
                Swal.fire(
                  'Accepted!',
                  'The request has been Canceled.',
                  'success'
                );
              },
              (error) => {
                console.error('Error updating request:', error);
  
                // Error SweetAlert
                Swal.fire(
                  'Error!',
                  'There was an issue accepting the request. Please try again.',
                  'error'
                );
              }
            );
          } else {
            // Cancelled SweetAlert
            Swal.fire(
              'Cancelled',
              'The request was not Cancelled.',
              'info'
            );
          }
        });
      },
      (error) => {
        console.error('Error fetching MakeRequest by ID:', error);
  
        // Error SweetAlert
        Swal.fire(
          'Error!',
          'Unable to fetch the request details. Please try again.',
          'error'
        );
      }
    );
  }




  AccpetRequest(requestId){
    console.log('Accept Request button clicked!');
    console.log("my ftt Tikit id  is ",requestId);
  
  
  
  
      
      // this.service.GetMakeRequestById(requestId).subscribe((result) => {
      //   this.makerequest=result
       
      //   this.makerequest.FttAgree="Yes"
      //   console.log(this.makerequest);
    
      //   this.service.UpdateMakeRequest( this.makerequest).subscribe(
      //     (updateResult) => {
      //       console.log('MakeRequest updated successfully:', updateResult);
      //       // Handle success response, e.g., show a success message
      //     },
      //     (error) => {
      //       console.error('Error updating profile:', error);
      //       // Handle error, e.g., show an error message
      //     }
      //   );
  
  
      //     });
   
  
        this.service.GetMakeRequestById(requestId).subscribe(
          (result) => {
            this.makerequest = result;
            this.makerequest.CompAgree = "Active";
            this.makerequest.CreatedBy = this.SID;
            // Display SweetAlert confirmation
            Swal.fire({
              title: 'Are you sure?',
              text: 'Do you want to accept this request?',
              icon: 'question',
              showCancelButton: true,
              confirmButtonText: 'Yes, accept it!',
              cancelButtonText: 'No, cancel',
            }).then((response) => {
              if (response.isConfirmed) {
                // Proceed with updating the request
                this.service.UpdateMakeRequest(this.makerequest).subscribe(
                  (updateResult) => {
                   // console.log('MakeRequest updated successfully:', updateResult);
      
                    // Success SweetAlert
                    Swal.fire(
                      'Accepted!',
                      'The request has been accepted.',
                      'success'
                    );
                  },
                  (error) => {
                    console.error('Error updating request:', error);
      
                    // Error SweetAlert
                    Swal.fire(
                      'Error!',
                      'There was an issue accepting the request. Please try again.',
                      'error'
                    );
                  }
                );
              } else {
                // Cancelled SweetAlert
                Swal.fire(
                  'Cancelled',
                  'The request was not accepted.',
                  'info'
                );
              }
            });
          },
          (error) => {
            console.error('Error fetching MakeRequest by ID:', error);
      
            // Error SweetAlert
            Swal.fire(
              'Error!',
              'Unable to fetch the request details. Please try again.',
              'error'
            );
          }
        );
      }





  GetAllMakeRequest(): void {
    this.service.GetAllMakeRequest().subscribe(
      (data) => {
        // this.RequestList = data;
        console.log('RequestList Data is ', data);
        // this.RequestList = data.filter(item => item.FttAgree =="Yes" );
        this.RequestList = data.filter(item => item.CompAgree == "Yes" && item.registration.RegistrationId ==this.SID);
        this.AcceptList = data.filter(item => item.FttAgree == "Yes");
       console.log("All Request Companioun",this.RequestList);
       console.log("All Acepted Companioun",this.AcceptList);

      },
      (error) => {
        console.error('Error fetching RequestList:', error);
        Swal.fire({
          title: 'Error!',
          text: 'Failed to load RequestList. Please try again later.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    );
  }
  toggleAccordion1(id: string): void {
    if (id === 'allRequests') {
      this.isAccordionOpen = !this.isAccordionOpen;
    }
  }
  






  
}