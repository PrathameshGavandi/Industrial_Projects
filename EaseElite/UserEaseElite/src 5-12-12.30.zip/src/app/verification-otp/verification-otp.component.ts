import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { Registration } from '../Class';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { WebService } from '../Service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-verification-otp',
  templateUrl: './verification-otp.component.html',
  styleUrls: ['./verification-otp.component.scss']
})
export class VerificationOtpComponent {
  


  @ViewChild('input1') input1!: ElementRef;
  @ViewChild('input2') input2!: ElementRef;
  @ViewChild('input3') input3!: ElementRef;
  @ViewChild('input4') input4!: ElementRef;
  @ViewChild('input5') input5!: ElementRef;
  @ViewChild('input6') input6!: ElementRef;


  Id: any;
  registration: Registration;
  Registrationlist: any[];
  showPassword: boolean;
  mainList: any[];
  otp1: any;
  otp2: any;
  otp3: any;
  otp4: any;
  otp5: any;
  otp6: any;

  constructor(private renderer: Renderer2, private router: Router, private http: HttpClient, private route: ActivatedRoute,
    private service: WebService) {
    this.registration = new Registration();
    this.Registrationlist = [];
    this.mainList = []

    this.route.params.subscribe((params) => {
      this.Id = params['Id'];
      console.log(" this.Id", this.Id)
    });

  }

  moveToNext(currentInput: any, nextInput: any): void {
    if (currentInput.value.length === 1) {
      nextInput.focus();
    }
  }
  SendOTPEmail() {


    this.service.GetRegistrationById(this.Id).subscribe((result) => {
      this.Registrationlist = []
      console.log(this.Registrationlist);
      
      this.mainList = []
  
      this.registration = result;
    });
    
  
    this.Registrationlist = []
    this.mainList = []
    console.log(this.registration.Email);
    
    
    this.service.SendOTPEmail(this.registration.Email).subscribe({
  
      next: (response) => {
        // alert("Otp Sent to your registered Email ")
  
  
        Swal.fire({
          icon: 'success',
          title: 'OTP Sent',
          text: 'OTP has been sent to your registered email address.',
          timer: 3000,
          showConfirmButton: false
        });
  
        console.log('Email sent successfully:', response);
        this.registration.OTPNo = response.otp;
        console.log('Received OTP:', this.registration.OTPNo);
  
        this.service.GetAllRegistration().subscribe((result) => {
          this.Registrationlist = result;
          this.mainList = this.Registrationlist.filter(x => x.Email == this.registration.Email);
  
          for (let data1 of this.mainList) {
            this.Id = data1.RegistrationId;
          }
  
          this.service.GetRegistrationById(this.Id).subscribe((result) => {
            this.registration = result;
            console.log("fun", this.registration);
            this.registration.OTPNo = response.otp;
            this.service.UpdateRegistration(this.registration).subscribe((result) => {
              if (result == 0) {
                // alert('Not updated!');
  
              } else {
                // alert('updated successfully');
                // this.router.navigateByUrl("/TermConditions/" + this.Id);
                // this.router.navigateByUrl("/ResetPassword/" + this.Id);
              }
            });
          });
        });
      }
    });
  }


  OnSubmit1() {
    this.Registrationlist = [];
    this.mainList = [];
  
    this.service.GetRegistrationById(this.Id).subscribe((result) => {
      this.registration = result;
      console.log("this.registration.OTPNo", this.registration.OTPNo);
  
      if (this.registration.OTPNo == this.otp1 + this.otp2 + this.otp3 + this.otp4 + this.otp5 + this.otp6) {
        // SweetAlert for OTP match success
        // Swal.fire({
        //   icon: 'success',
        //   title: 'OTP Matched!',
        //   text: 'Your OTP has been successfully verified.',
        //   confirmButtonText: 'OK'
        // });
  
        this.registration.EmailStatus = "Active";
        // Activate Email
        this.service.UpdateRegistration(this.registration).subscribe((result) => {
          if (result == 0) {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: 'Not updated!',
              confirmButtonText: 'OK'
            });
          } else {
            // SweetAlert for successful OTP match
            Swal.fire({
              icon: 'success',
              title: 'OTP Matched Successfully!',
              // text: 'You will now be redirected to the login page.',
              confirmButtonText: 'OK'
            }).then(() => {
              this.router.navigateByUrl("/ResetPassword/" + this.Id);
            });
          }
        });
      } else {
        // SweetAlert for OTP mismatch
        Swal.fire({
          icon: 'error',
          title: 'OTP Mismatch',
          text: 'The OTP you entered does not match.',
          confirmButtonText: 'Try Again'
        });
      }
    });
  }
  
}