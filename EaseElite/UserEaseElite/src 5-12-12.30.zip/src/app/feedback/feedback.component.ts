import { HttpClient } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import Swal from 'sweetalert2'; // SweetAlert2 import
import { Router } from '@angular/router';
import { WebService } from '../Service';
import { Feedback, Registration } from '../Class';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent {
  @ViewChild('form') form: NgForm;
  
  feedback: Feedback;
  registration = new Registration();
  id: any;
  SID: string;

  constructor(
    private router: Router,
    private http: HttpClient,
    private service: WebService
  ) {
    this.feedback = new Feedback();
  }

  validateWhitespace(control: any) {
    if (control.value && control.value.trim().length === 0) {
      control.setErrors({ whitespace: true });
    } else {
      control.setErrors(null);
    }
  }

  ngOnInit(): void {
    this.SID = sessionStorage.getItem('SID');
    console.log("SID",this.SID);
    
 
    this.GetInfo();
    }
  
    GetInfo(){
   
     
      
      this.service.GetRegistrationById(this.SID).subscribe((result) => {
       this.registration=result
       console.log("Registration  Info",result);
      
         });
  
  
        }

        OnSubmit() {
          this.feedback.RegistrationId = Number(this.SID);
          // console.log(this.SID);
          
         
        
          this.service.AddFeedback(this.feedback).subscribe(
            (result) => {
              if (result > 0) {
                Swal.fire('Success!', 'Feedback saved successfully.', 'success'); // SweetAlert success
                this.form.resetForm();
              } else {
                Swal.fire('Error!', 'Something went wrong! Please try again.', 'error'); // SweetAlert error
              }
            },
            (error) => {
              Swal.fire('Error!', 'Unable to save feedback. Please check your connection.', 'error'); // SweetAlert error
              console.error('AddFeedback Error:', error);
            }
          );
        }
        

  
}
