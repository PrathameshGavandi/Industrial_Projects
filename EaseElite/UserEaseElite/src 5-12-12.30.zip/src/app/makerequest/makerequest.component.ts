import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { WebService } from '../Service';

@Component({
  selector: 'app-makerequest',
  templateUrl: './makerequest.component.html',
  styleUrls: ['./makerequest.component.scss']
})
export class MakerequestComponent {
  message: any;
  isMessageSent: boolean = false; // Flag to disable the button

  constructor(private router: Router, private http: HttpClient, private service: WebService) {}

  ngOnInit(): void {
    // Retrieve the state data
    this.message = history.state?.message || 'No message available';
  }

  sendMessage(): void {
    // Simulate a message being sent
    this.isMessageSent = true; // Disable the button
    console.log('Message sent');

    // Example of enabling the button again after 5 seconds
    setTimeout(() => {
      this.isMessageSent = false;
    }, 5000); // Optional reset of the button for demonstration
  }
}
