import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarrierDetailChackoutComponent } from './carrier-detail-chackout.component';

describe('CarrierDetailChackoutComponent', () => {
  let component: CarrierDetailChackoutComponent;
  let fixture: ComponentFixture<CarrierDetailChackoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarrierDetailChackoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarrierDetailChackoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
