import { Component, ElementRef, VERSION, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Registration, UserProfile } from '../Class';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { GlobalVariable } from '../Global';
import { WebService } from '../Service';
import { City, Country, State } from 'country-state-city';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent {

  @ViewChild('country') country: ElementRef
  @ViewChild('city') city: ElementRef
  @ViewChild('state') state: ElementRef
  name = 'Angular ' + VERSION.major;
  countries = Country.getAllCountries();
  states = null;
  cities = null;

  selectedCountry;
  selectedState;
  selectedCity;
  



  // userprofile: UserProfile;
  // registration:Registration;
  imgPath: string = GlobalVariable.BASE_API_URL;

  userprofile = new UserProfile();
registration = new Registration();

// photoURL: string;
  filesToUpload: Array<File> = [];

  photoURL: string | ArrayBuffer | null = null; // Added for image preview


 
  UserProfileList1: any;
  userProfileList: any;
  UserProfileList: any;
  id
  selectedFileNames: any[];
  UserProfileId: any;

  constructor(private router: Router, private http: HttpClient, private service: WebService) {
  
    this.registration = new Registration();
    this.userprofile.registration = new Registration();


    
   this.id= sessionStorage.getItem('SID');
   console.log(" My ID",this.id);
  
   
  }


  //====================================================================================
  ngOnInit(): void {
 
  this.GetInfo();
  }

  GetInfo(){
 
    this.service.GetRegistrationById(this.id).subscribe((result) => {
     this.registration=result
     console.log("Registration  Info",result);
    
       });

   
      this.service.GetUserProfileById(this.id).subscribe((result) => {
        this.userprofile=result
        console.log("User Info",result);
       
          });

      }
  //=========================================================

  
  delete(UserProfileId) {
    let confirmAction = confirm("Are you sure you want to delete");
    if (confirmAction) {
    this.service.DeleteUserProfile(UserProfileId).subscribe(result => {
    if (result == "Success") {
    this.UserProfileList1 = this.userProfileList.filter(
      item => item.UserProfileld !==  this.UserProfileList)
    alert("Deleted Successfully");
    // this.GetAllUserProfile()
    }
      });
      } else {
    alert("Action canceled");
    }
    }

    
    onUpdate(): void {
     
      this.service.GetRegistrationById(this.userprofile.RegistrationId).subscribe(
        (result) => {
          this.userprofile = result; // Update userprofile with fetched data
          console.log("Fetched registration: ", this.userprofile);
    
       
        },
        (error) => {
          console.error("Error fetching registration: ", error);
          Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Could not fetch registration details. Please try again.',
            confirmButtonColor: '#d33'
          });
        }
      );
    }
    
  onSubmit(): void {
    
    
  
    this.userprofile.Country=this.selectedCountry.name
    this.userprofile.Province=this.selectedState.name
    this.userprofile.City=this. selectedCity.name
       this.userprofile.Passport=""
       this.userprofile.AddressProof=""
       this.userprofile.KycStatus=""
      //  this.userprofile.Image="Abc"
       this.userprofile.Status="Active"

         console.log("userprofile",this.userprofile);
         
    this.service.UpdateUserProfile(this.userprofile).subscribe(result => {
      if (result > 0) {
        const formData = new FormData();
        formData.append('uploadedImage', this.filesToUpload[0], this.filesToUpload[0].name);
    
    // this.service.AddUserProfile(this.userprofile).subscribe(result => {
    //   if (result > 0) {
    //     const formData = new FormData();
    //     formData.append('uploadedImage', this.filesToUpload[0], this.filesToUpload[0].name);

        this.service.SaveUserProfileImage(formData, this.userprofile.UserProfileId).subscribe(() => {
       
        });
      // } else {
      //   Swal.fire({
      //     icon: 'error',
      //     title: 'Oops...',
      //     text: 'Something went wrong! Please try again.',
      //     confirmButtonColor: '#d33',
      //     confirmButtonText: 'Retry'
      //   });
      }
    });
   Swal.fire({
            icon: 'success',
            title: 'Saved Successfully!',
            text: 'Your profile has been saved successfully.',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK'
          }).then(() => {
            // Optional: Navigate to another route after the user confirms
            // this.router.navigateByUrl('/UserProfile');
          });
  }

  
//   fileChangeEvent(fileInput: any): void {
//     this.filesToUpload = <Array<File>>fileInput.target.files;
//     if (this.filesToUpload.length > 0) {
//       this.userprofile.Image = this.filesToUpload[0].name;
//     
//     }
//   }


isEmailValid(email: string): boolean {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
}

noWhitespaceValidator(control: any) {
    if (control.value && control.value.trim().length === 0) {
      control.setErrors({ whitespace: true });
    } else {
      control.setErrors(null);
    }
  }
  
  fileChangeEvent(fileInput: any): void {
    this.filesToUpload = <Array<File>>fileInput.target.files;
    if (this.filesToUpload.length > 0) {
      const file = this.filesToUpload[0];
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.photoURL = e.target.result; // Set the photo preview
      };
      reader.readAsDataURL(file);
    }
  }
//=========================all update heare===============================================

onCountryChange($event): void {
  this.states = State.getStatesOfCountry(JSON.parse(this.country.nativeElement.value).isoCode);
  this.selectedCountry = JSON.parse(this.country.nativeElement.value);
  this.cities = this.selectedState = this.selectedCity = null;
}

onStateChange($event): void {
  this.cities = City.getCitiesOfState(JSON.parse(this.country.nativeElement.value).isoCode, JSON.parse(this.state.nativeElement.value).isoCode)
  this.selectedState = JSON.parse(this.state.nativeElement.value);
  this.selectedCity = null;

}

onCityChange($event): void {
  this.selectedCity = JSON.parse(this.city.nativeElement.value)
}

clear(type: string): void {
  switch(type) {
    case 'country':
      this.selectedCountry = this.country.nativeElement.value = this.states = this.cities = this.selectedState = this.selectedCity = null;
      break;
    case 'state':
      this.selectedState = this.state.nativeElement.value = this.cities = this.selectedCity = null;
      break;
    case 'city':
      this.selectedCity = this.city.nativeElement.value = null;
      break;
  }
}

}