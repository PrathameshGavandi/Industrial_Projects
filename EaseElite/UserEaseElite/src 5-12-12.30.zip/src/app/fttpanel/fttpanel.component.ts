import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Registration, UserProfile } from '../Class';
import { WebService } from '../Service';
import { GlobalVariable } from '../Global';

@Component({
  selector: 'app-fttpanel',
  templateUrl: './fttpanel.component.html',
  styleUrls: ['./fttpanel.component.scss']
})
export class FttpanelComponent {

  imgPath: string = GlobalVariable.BASE_API_URL;

  userprofile = new UserProfile();
registration = new Registration();


  isSidebarOpen = false;  // Variable to control sidebar visibility
  dropdownOpen = false;    // Variable to control dropdown visibility

id;
  SaveFttDetailImage: any;
  constructor(private router: Router, private http: HttpClient, private service: WebService) {
  
    this.registration = new Registration();
    this.userprofile.registration = new Registration();


    
   this.id= sessionStorage.getItem('SID');
   console.log(" My ID",this.id);
  
   
  }


  ngOnInit(): void {
 
    this.GetInfo();
    
    this.service.GetAllUserProfile().subscribe((result) => {
          
           
    });

 
    }
  

  GetInfo(){
 
    this.service.GetRegistrationById(this.id).subscribe((result) => {
     this.registration=result
     console.log("Registration  Info",result);
    
       });

   
      this.service.GetUserProfileById(this.id).subscribe((result) => {
        this.userprofile=result
        console.log("User Info",result);
       
          });
          

      }


  toggleSidebar() {
      this.isSidebarOpen = !this.isSidebarOpen;
  }

  toggleDropdown() {
      this.dropdownOpen = !this.dropdownOpen;
  }
  isMenuOpen = false;

  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }
  selectRole(role: string, route: string) {
      // Logic for selecting a role and navigating
      console.log(`Role selected: ${role}`);
      // Example: Navigate to the selected route
      this.router.navigate([route]);
  }
 


  logout() {
    this.router.navigate(['/login']);
  }

//   previewImage(event: Event) {
//     const input = event.target as HTMLInputElement;
//     if (input.files && input.files[0]) {
//         const reader = new FileReader();
//         reader.onload = (e: any) => {
//             this.userprofile.Image = e.target.result; // Update the image preview
//             const imgElement = document.getElementById('uploadedImage') as HTMLImageElement;
//             imgElement.src = e.target.result; // Set the preview image source
//         };
//         reader.readAsDataURL(input.files[0]); // Read the file as a data URL
//     }
// }



}
