import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Registration, UserProfile } from '../Class';
import { WebService } from '../Service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-kyc',
  templateUrl: './kyc.component.html',
  styleUrls: ['./kyc.component.scss']
})
export class KycComponent implements OnInit {
  userprofile1: Registration;
  userprofile: UserProfile;
  kycDocumentsList: any;
  passportFile: File | null = null;
  addressProofFile: File | null = null;
  SID: any;
  kycCompleted: boolean = false; // Track if KYC is already completed

  constructor(private router: Router, private http: HttpClient, private service: WebService) {
    this.userprofile = new UserProfile();
    this.userprofile1 = new Registration();
  }

  ngOnInit(): void {
    this.SID = sessionStorage.getItem('SID'); // Get the user session ID
    this.service.GetUserProfileById(this.SID).subscribe(result => {
      this.userprofile = result;

      // Check if KYC is Approve for the user
      if (this.userprofile.KycStatus === 'Approve') {
        this.kycCompleted = true;
        Swal.fire({
          icon: 'info',
          title: 'KYC Already Approve',
          text: 'Your KYC has been Approve. Submission is disabled.',
          confirmButtonText: 'OK'
        });
      }
    });
    this.getUserKycDocuments(); // Get KYC documents list for the specific user
  }

  isFormValid(): boolean {
    return this.passportFile !== null && this.addressProofFile !== null;
  }

  onSubmit(): void {
    if (!this.passportFile || !this.addressProofFile) {
      // Swal.fire({
      //   icon: 'warning',
      //   title: 'Upload Required',
      //   text: 'Please upload both Passport and Address Proof documents.',
      //   confirmButtonText: 'OK'
      // });
      return;
    }

    this.userprofile.registration.RegistrationId = this.SID;
    this.userprofile.KycStatus = "Submit";

    if (this.kycCompleted) {
      // Swal.fire({
      //   icon: 'info',
      //   title: 'KYC Already Completed',
      //   text: 'You have already completed your KYC successfully.',
      //   confirmButtonText: 'OK'
      // });
      return;
    }

    // Update user profile
    this.service.UpdateUserProfile(this.userprofile).subscribe(result => {
      if (result > 0) {
        const formData = new FormData();

        // Append passport file if available
        if (this.passportFile) {
          const passportFileName = "PassP_" + this.passportFile.name;
          formData.append('passport', this.passportFile, passportFileName);
        }

        // Append address proof file if available
        if (this.addressProofFile) {
          const addressProofFileName = "AddressP_" + this.addressProofFile.name;
          formData.append('addressProof', this.addressProofFile, addressProofFileName);
        }

        // Save KYC documents
        this.service.SaveKycImage(formData, this.userprofile.UserProfileId).subscribe(() => {
          Swal.fire({
            icon: 'success',
            title: 'KYC Successful',
            text: 'Your KYC documents has been successfully.',
            confirmButtonText: 'OK'
          }).then(() => {
            this.kycCompleted = true; // Disable further submissions
            this.getUserKycDocuments(); // Refresh the list of documents
          });
        }, (error) => {
          console.error('Error saving KYC images:', error);
          // Swal.fire({
          //   icon: 'error',
          //   title: 'Upload Failed',
          //   text: 'Failed to upload KYC documents. Please try again.',
          //   confirmButtonText: 'OK'
          // });
        });
      } else {
        // Swal.fire({
        //   icon: 'error',
        //   title: 'Update Failed',
        //   text: 'Something went wrong! Please try again.',
        //   confirmButtonText: 'OK'
        // });
      }
    }, (error) => {
      console.error('Error updating user profile:', error);
      // Swal.fire({
      //   icon: 'error',
      //   title: 'Update Failed',
      //   text: 'Failed to update user profile. Please try again.',
      //   confirmButtonText: 'OK'
      // });
    });
  }

  getUserKycDocuments(): void {
    // Fetch user-specific KYC documents
    this.service.GetAllUserProfile().subscribe(data => {
      // Filter documents for the logged-in user based on SID (session ID)
      this.kycDocumentsList = data.filter(user => user.registration.RegistrationId == this.SID);
      console.log("Filtered KYC Documents for User:", this.kycDocumentsList);
    });
  }

  fileChangeEvent(event: any, fileType: string): void {
    const file = event.target.files[0];
    if (fileType === 'passport') {
      this.passportFile = file;
    } else if (fileType === 'addressProof') {
      this.addressProofFile = file;
    }
  }
}
