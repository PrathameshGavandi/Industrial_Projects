import { Component } from '@angular/core';
import { AirportService } from '../airport.service';
import { CompanionDetail, FlightDetailsFirsttimeTraveller, FttDetail, Registration, UserProfile } from '../Class';
import Swal from 'sweetalert2';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { WebService } from '../Service';

@Component({
  selector: 'app-firsttime-traveller-details',
  templateUrl: './firsttime-traveller-details.component.html',
  styleUrls: ['./firsttime-traveller-details.component.scss']
})
export class FirsttimeTravellerDetailsComponent {

  isModalOpen: boolean = false;  // Flag to control modal visibility

  minDate: string;
  userprofile1: Registration;
  userprofile: UserProfile;
  kycDocumentsList: any;
  kycCompleted: boolean = false;  // Track if KYC is already completed
  myfttid;
  activeAccordion: number | null = null;
  fttDetail: FttDetail;
  CompanionsList: any;
  FttList: any;
  filteredCompanions: any[] = []; // Filtered list based on dropdown selection
  anotherList: any[] = []; // Example list to compare with
  selectedFtt
  isAccordionOpen: boolean = false;
  isAccordionOpen2: boolean = false;
  isAccordionOpen3: boolean = false;
//  FttList:FttDetail[]=[]
  searchTermFrom: string = '';
  filteredAirportsFrom: any[] = [];
  isDropdownOpenFrom: boolean = false;
  searchTermTo: string = '';
  filteredAirportsTo: any[] = [];
  isDropdownOpenTo: boolean = false;
  Rlist:any[]=[]
  MRlist:any[]=[]
  airports: any[] = [];
  selectedAirportFrom: any = null;
  selectedAirportTo: any = null;
  submittedFlightDetails: any = null;
  filesToUpload: File[] = [];

  SID: any;
  filteredFttList:any;
  DeleteFttDetail: any;
  GetFttDetailById:any;
  RequestList: any;
  AcceptList: any;
  isFirstAccordionOpen: boolean = false;
  isSecondAccordionOpen: boolean = false;
  makerequest:any


  cmpDetail:CompanionDetail;
  RegDetail:Registration

  yeslist:any;
  allRLlist:any;
  



  constructor(
    private airportService: AirportService,
    private router: Router,
    private http: HttpClient,
    private service: WebService
  ) {
    this.fttDetail = new FttDetail();
    this.cmpDetail=new CompanionDetail()
    this.RegDetail=new Registration()
  }

  ngOnInit() {
    this.GetAllCompanionDetail();
    this.GetAllFttDetail();

   this.GetAllMakeRequest();

    const today = new Date();
    this.minDate = today.toISOString().split('T')[0]; // Format as YYYY-MM-DD

    this.SID = sessionStorage.getItem('SID'); // Get the user session ID
    this.service.GetUserProfileById(this.SID).subscribe(result => {
      this.userprofile = result;

      // Check if KYC is approved for the user
      if (this.userprofile.KycStatus === 'Approve') {
        this.kycCompleted = true;
        // console.log("my kyc is " ,this.kycCompleted);
        
        // Swal.fire({
        //   icon: 'info',
        //   title: 'KYC Already Approved',
        //   text: 'Your KYC has been approved. Submission is disabled.',
        //   confirmButtonText: 'OK'
        // });
      }
    }); 

   

    // this.SID = sessionStorage.getItem('SID');

    // Fetch airports data
    this.airportService.getAirports().subscribe((data: any[]) => {
      this.airports = data;
 
    });




    this.service.GetAllRegistration().subscribe(
      (data) => {
       this.Rlist=data
       console.log("All Registration data is ", this.Rlist);
       
        });

        
    this.service.GetAllMakeRequest().subscribe(
      (data) => {
       this.MRlist=data
       console.log("All AllMakeRequest data is ", this.MRlist);
       
        });
    
  }
  toggleAccordion(id: number): void {
    this.MRlist = this.MRlist.map((item) => {
      if (item.MakeRequestId === id) {
        item.isOpen = !item.isOpen;
      } else {
        item.isOpen = false; // Close other accordion items
      }
      return item;
    });
  }
  

  //=================================================================================

  GetAllCompanionDetail(): void {
    this.service.GetAllCompanionDetail().subscribe(
      (data) => {
        this.CompanionsList = data;
        console.log('CompanionsList Data is ', data);
      },
      (error) => {
        console.error('Error fetching CompanionsList:', error);
        Swal.fire({
          title: 'Error!',
          text: 'Failed to load CompanionsList. Please try again later.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    );
  }


 //============================================================
  GetAllFttDetail(): void {
    this.service.GetAllFttDetail().subscribe(
      (data) => {
        // this.FttList = data;
        this.FttList = data.filter(item => item.RegistrationId ==this.SID );
        console.log('FttList Data is ', this.FttList);
      },
      (error) => {
        console.error('Error fetching FttList:', error);
        Swal.fire({
          title: 'Error!',
          text: 'Failed to load FttList. Please try again later.',
          icon: 'error',
          confirmButtonText: 'OK'
        });
      }
    );
  }
 
  //======================================================================

  onSearchFrom() {
    const searchTermLower = this.searchTermFrom.toLowerCase();
    
    this.filteredAirportsFrom = this.airports
      .filter((airport) => airport.name.toLowerCase().startsWith(searchTermLower))
      .sort((a, b) => a.name.localeCompare(b.name)); // Sorting alphabetically
    
    this.isDropdownOpenFrom = this.filteredAirportsFrom.length > 0;
  }
  
  onSearchTo() {
    const searchTermLower = this.searchTermTo.toLowerCase();
    
    this.filteredAirportsTo = this.airports
      .filter((airport) => airport.name.toLowerCase().startsWith(searchTermLower))
      .sort((a, b) => a.name.localeCompare(b.name)); // Sorting alphabetically
    
    this.isDropdownOpenTo = this.filteredAirportsTo.length > 0;
  }
  

  onSelectAirportFrom(airport: any) {
    this.selectedAirportFrom = airport;
    this.searchTermFrom = airport.name;
    this.fttDetail.From1 = airport.name;
    this.filteredAirportsFrom = [];
    this.isDropdownOpenFrom = false;
  }

  onSelectAirportTo(airport: any) {
    this.selectedAirportTo = airport;
    this.searchTermTo = airport.name;
    this.fttDetail.To1 = airport.name;
    this.filteredAirportsTo = [];
    this.isDropdownOpenTo = false;
  }

  
  fileChangeEvent(fileInput: any): void {
    this.filesToUpload = <Array<File>>fileInput.target.files; // Cast file input to File array
    if (this.filesToUpload.length > 0) {
      this.fttDetail.UploadTicket = this.filesToUpload[0].name; // Store the file name in the object
    }
  }
  // Submit flight details
//================================================================
//   onSubmit() {
//   if (!this.kycCompleted) {
//     // Show alert for incomplete KYC
//     Swal.fire({
//       title: 'KYC Incomplete',
//       text: 'Please complete your KYC before submitting the form.',
//       icon: 'warning',
//       confirmButtonText: 'OK'
//     }).then((result) => {
//       if (result.isConfirmed) {
//         // Redirect to another route after confirmation
//         this.router.navigate(['/kyc']); // Replace with your actual route
//       }
//     });
//   } else {
//     // Assign the session ID to the fttDetail object
//     this.fttDetail.RegistrationId = this.SID;
//     console.log("AddFttDetail", this.fttDetail);
    
//     // Add the FTT detail (Submit flight details)
//     this.service.AddFttDetail(this.fttDetail).subscribe((result) => {
//       if (result > 0) {
//         const formData = new FormData();
//         formData.append('uploadedImage', this.filesToUpload[0], this.filesToUpload[0].name);

//         // Save uploaded image
//         this.service.SaveFttDetailImage(formData, result).subscribe(() => {
//           // Reset form after successful submission
//           // Optionally, call onAccordionToggle after successful submission
          
//           const fttId = result; // Assuming `result` contains the new FttId
//           const index = this.FttList.findIndex((item) => item.FttId === fttId); // Find the index of the new item
//           if (index !== -1) { // Check for valid index
//             this.onAccordionToggle(fttId, index); // Call the toggle function
//           }

//           // Refresh the list of FTT details after submission
//           this.GetAllFftDetail(); // This will reload the FTT List
//         });
//       }
//     });
//   }


  
// }

//====================================================================    

   

onSubmit() {
  if (!this.kycCompleted) 
    {
    // Show alert for incomplete KYC
    Swal.fire({
      title: 'KYC Incomplete',
      text: 'Please complete your KYC before submitting the form.',
      icon: 'warning',
      confirmButtonText: 'OK'
    }).then((result) => {
      if (result.isConfirmed) {
        // Redirect to KYC page
        this.router.navigate(['/kyc']);
      }
    });




    
  } else {
    // Check if the user's SID and role exist in the user role table
    this.service.GetAllUserRole().subscribe((Result) => {
      console.log(Result);
      const isValid = Result.some(
        (role) => role.RegistrationId == this.SID && role.RoleId == 2
      );

      if (isValid) {
        // If valid, proceed with form submission
        this.fttDetail.RegistrationId = this.SID;
        this.fttDetail.CreatedBy = "Active";
        console.log("AddFttDetail", this.fttDetail);

        this.service.AddFttDetail(this.fttDetail).subscribe((result) => {
          if (result > 0) {
            const formData = new FormData();
            formData.append('uploadedImage', this.filesToUpload[0], this.filesToUpload[0].name);

            // Save the uploaded image
            this.service.SaveFttDetailImage(formData, result).subscribe(() => {
              // Refresh the list of FTT details after submission
              const fttId = result;
              const index = this.FttList.findIndex((item) => item.FttId === fttId);
              if (index !== -1) {
                this.onAccordionToggle(fttId, index);
              }

              this.GetAllFttDetail();
            });
          }
        });
      } else {
        // If not valid, redirect to purchase plan
        Swal.fire({
          title: 'Access Denied',
          text: 'Would you like to proceed with this amazing plan? Unlock premium features now!',
          icon: 'error',
          confirmButtonText: 'Yes, Proceed'
        }).then((result) => {
          if (result.isConfirmed) {
            this.router.navigate(['/fttsubscription']);
          }
        });
      }
    });
  }
}

formatDate(date: string): string {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(date).toLocaleDateString(undefined, options);
}

// Format Time
formatTime(time: string): string {
  const [hour, minute] = time.split(':').map(Number);
  const isPM = hour >= 12;
  const formattedHour = hour % 12 || 12;
  return `${formattedHour}:${minute.toString().padStart(2, '0')} ${isPM ? 'PM' : 'AM'}`;
}



deleteFtt(id: number): void {
  Swal.fire({
    title: 'Are you sure?',
    text: 'You won’t be able to revert this!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      // Retrieve Ftt Detail by ID
      this.service.GetFttDetailById(id).subscribe({
        next: (fttDetail) => {
          if (!fttDetail) {
            Swal.fire({
              title: 'Error!',
              text: 'Record not found.',
              icon: 'error',
              confirmButtonText: 'Ok'
            });
            return;
          }

          // Update FttDetail Status to "InActive"
          const updatedFttDetail = { ...fttDetail, CreatedBy: 'InActive' };
          this.service.UpdateFttDetail(updatedFttDetail).subscribe({
            next: (updateResult) => {
              if (updateResult === 0) {
                Swal.fire({
                  title: 'Error!',
                  text: 'Could not delete the record. Please try again.',
                  icon: 'error',
                  confirmButtonText: 'Ok'
                });
              } else {
                Swal.fire(
                  'Deleted!',
                  'The record has been deleted successfully.',
                  'success'
                );
                // Refresh the list of Ftt Details
                this.GetFttDetailById(); // Call a separate function to reload the data
              }
            },
         
          });
        },
        error: (err) => {
          console.error('Error retrieving FttDetail:', err);
          Swal.fire({
            title: 'Error!',
            text:'Something went wrong while deleting. Please try again.',
            icon: 'error',
            confirmButtonText: 'Ok'
          });
        }
      });
    }
  });
}



//========================================================================================================

// compareWithAnotherList(): void {
//   console.log('Selected FTT ID:', this.selectedFtt);
//   const selectedFttDetails = this.FttList.find(
//     (ftt) => ftt.FttId == this.selectedFtt
//   );

//   console.log('Selected FTT Details:', selectedFttDetails);

//   if (selectedFttDetails) {
//     this.filteredCompanions = this.CompanionsList.filter(
//       (companion) =>
//         companion.From1 == selectedFttDetails.From1 &&
//         companion.To1 == selectedFttDetails.To1
//     );
//   } else {
//     this.filteredCompanions = [];
//   }
// }


onAccordionToggle(fttId: number, index: number): void {
  // Toggle active accordion
  if (this.activeAccordion === index) {
    this.activeAccordion = null; // Close if already open
    this.filteredCompanions = [];
  } else {
    this.activeAccordion = index; // Open the clicked accordion
    this.compareWithAnotherList(fttId); // Fetch and filter data
  }
}

compareWithAnotherList(fttId: number): void {
  console.log('Selected FTT ID:', fttId);
this.myfttid =fttId;
  const selectedFttDetails = this.FttList.find((ftt) => ftt.FttId === fttId);

  console.log('Selected FTT Details:', selectedFttDetails);

  if (selectedFttDetails) {
    this.filteredCompanions = this.CompanionsList.filter(
      (companion) =>
        companion.From1 === selectedFttDetails.From1 &&
        companion.To1 === selectedFttDetails.To1 &&
        companion.Date === selectedFttDetails.Date 
        // companion.Time === selectedFttDetails.Time 
    );
  } else {
    this.filteredCompanions = [];
  }

  console.log('Filtered Companions:', this.filteredCompanions);
}


makeRequest(companionId: number): void {
  console.log('Make Request for Companion ID:', companionId);

  // Navigate to the companion view page with the ID
  // this.router.navigate(['/companionview', companionId]);

  
  //  this.router.navigate(['/companionview', companionId, this.myfttid ])

  this.router.navigate(['/companionview', companionId], { 
    queryParams: { myFttId: this.myfttid } 
  });
  }


// getname(UId: number): string {
//   const ResName = this.Rlist.filter(res => res.RegistrationId === UId);

//   if (ResName.length > 0) {
//     return ResName[0].FName; // Access the first item in the array and its 'FName' property
//   } else {
//     return 'NoImageAvailable.png'; // Default value when no matching record is found
//   }
// }


getname(UId: number): string {
  const ResName = this.Rlist.filter(res => res.RegistrationId === UId);

  if (ResName.length > 0) {
    return `${ResName[0].FName} ${ResName[0].LName}`; // Concatenate FName and Lanem
  } else {
    return 'NoImageAvailable.png'; // Default value when no matching record is found
  }
}



////////===============================================================//////////////////

// GetAllMakeRequest(): void {
//   this.service.GetAllMakeRequest().subscribe(
//     (data) => {
//       // this.FttList = data;
//       this.MRlist = data.filter(item => item.RegistrationId ==this.SID );
//       console.log('MAkeRequest Data is ', this.MRlist);
//     },
//     (error) => {
//       console.error('Error fetching FttList:', error);
//       Swal.fire({
//         title: 'Error!',
//         text: 'Failed to load FttList. Please try again later.',
//         icon: 'error',
//         confirmButtonText: 'OK'
//       });
//     }
//   );
// }


GetAllMakeRequest(): void {
  this.service.GetAllMakeRequest().subscribe(
    (data) => {
      // this.allRLlist = data;
      console.log('RequestList Data is ', data);
      // this.RequestList = data.filter(item => item.FttAgree =="Yes" );
      this.RequestList = data.filter(item => item.FttAgree == "Yes" && item.registration.RegistrationId ==this.SID);
      this.AcceptList = data.filter(item => item.CompAgree == "Yes");


      this.allRLlist = data.filter(item => item.FttAgree == "Yes"  && item.CompAgree == "Active" &&  item.registration.RegistrationId ==this.SID);
   console.log("dfgdgdgdgd",this.allRLlist);
   
    },
    (error) => {
      console.error('Error fetching RequestList:', error);
      Swal.fire({
        title: 'Error!',
        text: 'Failed to load RequestList. Please try again later.',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    }
  );
} 



toggleAccordion1(id: string): void {
  if (id === 'allRequests') {
    this.isAccordionOpen = !this.isAccordionOpen;
  }
}



toggleAccordion2(id: string): void {
  if (id === 'allRequests2') {
    this.isAccordionOpen2 = !this.isAccordionOpen2;
  }
}



toggleAccordion3(id: string): void {
  if (id === 'allRequests3') {
    this.isAccordionOpen3 = !this.isAccordionOpen3;
  }
}



// toggleAccordion1(section: string): void {
//   if (section === 'firstRequest') {
//     this.isFirstAccordionOpen = !this.isFirstAccordionOpen;
//     this.isSecondAccordionOpen = false; // Ensure other accordion is closed
//   } else if (section === 'secondRequest') {
//     this.isSecondAccordionOpen = !this.isSecondAccordionOpen;
//     this.isFirstAccordionOpen = false; // Ensure other accordion is closed
//   }
// }



AccpetRequest(requestId){
  console.log('Accept Request button clicked!');
  console.log("my ftt Tikit id  is ",requestId);




    
    // this.service.GetMakeRequestById(requestId).subscribe((result) => {
    //   this.makerequest=result
     
    //   this.makerequest.FttAgree="Yes"
    //   console.log(this.makerequest);
  
    //   this.service.UpdateMakeRequest( this.makerequest).subscribe(
    //     (updateResult) => {
    //       console.log('MakeRequest updated successfully:', updateResult);
    //       // Handle success response, e.g., show a success message
    //     },
    //     (error) => {
    //       console.error('Error updating profile:', error);
    //       // Handle error, e.g., show an error message
    //     }
    //   );


    //     });
 

      this.service.GetMakeRequestById(requestId).subscribe(
        (result) => {
          this.makerequest = result;
          this.makerequest.FttAgree = "Active";
          this.makerequest.CreatedBy = this.SID;
          // Display SweetAlert confirmation
          Swal.fire({
            title: 'Are you sure?',
            text: 'Do you want to accept this request?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, accept it!',
            cancelButtonText: 'No, cancel',
          }).then((response) => {
            if (response.isConfirmed) {
              // Proceed with updating the request
              this.service.UpdateMakeRequest(this.makerequest).subscribe(
                (updateResult) => {
                 // console.log('MakeRequest updated successfully:', updateResult);
    
                  // Success SweetAlert
                  Swal.fire(
                    'Accepted!',
                    'The request has been accepted.',
                    'success'
                  );
                },
                (error) => {
                  console.error('Error updating request:', error);
    
                  // Error SweetAlert
                  Swal.fire(
                    'Error!',
                    'There was an issue accepting the request. Please try again.',
                    'error'
                  );
                }
              );
            } else {
              // Cancelled SweetAlert
              Swal.fire(
                'Cancelled',
                'The request was not accepted.',
                'info'
              );
            }
          });
        },
        (error) => {
          console.error('Error fetching MakeRequest by ID:', error);
    
          // Error SweetAlert
          Swal.fire(
            'Error!',
            'Unable to fetch the request details. Please try again.',
            'error'
          );
        }
      );
    }
    

    CancelRequest(requestId){
      this.service.GetMakeRequestById(requestId).subscribe(
        (result) => {
          this.makerequest = result;
          this.makerequest.FttAgree = "";
    
          // Display SweetAlert confirmation
          Swal.fire({
            title: 'Are you sure?',
            text: 'Do you want to Cancel this request?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, Cancel it!',
            cancelButtonText: 'No, cancel',
          }).then((response) => {
            if (response.isConfirmed) {
              // Proceed with updating the request
              this.service.UpdateMakeRequest(this.makerequest).subscribe(
                (updateResult) => {
                  console.log('MakeRequest updated successfully:', updateResult);
    
                  // Success SweetAlert
                  Swal.fire(
                    'Accepted!',
                    'The request has been Canceled.',
                    'success'
                  );
                },
                (error) => {
                  console.error('Error updating request:', error);
    
                  // Error SweetAlert
                  Swal.fire(
                    'Error!',
                    'There was an issue accepting the request. Please try again.',
                    'error'
                  );
                }
              );
            } else {
              // Cancelled SweetAlert
              // Swal.fire(
              //   'Cancelled',
              //   'The request was not Cancelled.',
              //   'info'
              // );
            }
          });
        },
        (error) => {
          // console.error('Error fetching MakeRequest by ID:', error);
    
          // Error SweetAlert
          // Swal.fire(
          //   'Error!',
          //   'Unable to fetch the request details. Please try again.',
          //   'error'
          // );
        }
      );
    }


    ViewCmpDeatil(id){

      this.service.GetMakeRequestById(id).subscribe(
        (result) => {
          console.log(result);
          
          console.log('Registration ID:',result.registration. RegistrationId);
          console.log('Ticket ID:',result. TicketId);



          this.service.GetCompanionDetailById(result.TicketId).subscribe(
            (result) => {

              
              this.cmpDetail=result

              console.log("Camp Detail",result);
              
              // console.log('Registration ID:',result.registration. RegistrationId);
              // console.log('Ticket ID:',result. TicketId);
            });



            this.service.GetRegistrationById(result.TicketId).subscribe(
              (result) => {

                this.RegDetail=result
                console.log("Registration  Detail",result);
                this.isModalOpen = true;
                // console.log('Registration ID:',result.registration. RegistrationId);
                // console.log('Ticket ID:',result. TicketId);
              });


        });  

    }
    openModal() {
      this.isModalOpen = true;
    }
  
    // This method will close the modal
    closeModal() {
      this.isModalOpen = false;
    }

    
   
    

    
}
