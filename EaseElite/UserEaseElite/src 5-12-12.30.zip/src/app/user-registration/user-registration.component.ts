import { Component } from '@angular/core';
import { Registration, UserProfile } from '../Class';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { WebService } from '../Service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent {
  userprofile=new UserProfile();
  registration: Registration;
  showPopup: boolean;
  showSuccessMessage: boolean;
  registrationList: any[] = [];
  userRole: any = {}; // Initialize userRole to avoid undefined errors
  mainlist: any[];
  Emailid: string;
  mainlist1: any[];
  RegistrationId: any;

  constructor(private router: Router, private http: HttpClient, private service: WebService) {
    this.registration = new Registration();
    this.userprofile.registration = new Registration();
  }

  showPassword: boolean = false;
  showConfirmPassword: boolean = false;

  togglePasswordVisibility(type: string) {
    if (type === 'password') {
      this.showPassword = !this.showPassword;
    } else if (type === 'confirmPassword') {
      this.showConfirmPassword = !this.showConfirmPassword;
    }
  }

  onSubmit() {
    if (!this.isFormValid()) {
      Swal.fire('Validation Error', 'Please fill in all required fields correctly.', 'error');
      return;
    }

    console.log("this.registration", this.registration);
    console.log("this.registration.Email", this.registration.Email);

    this.service.GetAllRegistration().subscribe((result) => {
      this.registrationList = result; 
      this.mainlist = this.registrationList.filter(x => x.Email === this.registration.Email);
      
      console.log("this.mainlist.length", this.mainlist.length);
      
      if (this.mainlist.length > 0) {
        Swal.fire('Error', 'This email is already registered', 'error');
        return; 
      }

      // Prepare registration data
      this.registration.EmailStatus = "Active";
      this.registration.OTPNo = "";
      this.registration.DefaultRole = "1";
      this.registration.Status = "Active";

      this.service.AddRegistration(this.registration).subscribe((result) => {
        if (result > 0) {
          // Swal.fire('Success', 'User Registered Successfully.', 'success');

          //this.router.navigateByUrl('/VerifyEmail/${result}');
          this.router.navigateByUrl('/VerifyEmail/' + result);

          // Add default user role as an EndUser
          this.userRole.RegistrationId = result;
          this.userRole.RoleId = 1;
          this.userRole.Status = "Active";

          // Prepare user profile data
          this.userprofile.registration.RegistrationId = result; // Fix assignment
          this.userprofile.ContactNumber = "";
          this.userprofile.Address = "";
          this.userprofile.AlternativeEmail = "";
          this.userprofile.Country = "";
          this.userprofile.Province = "";
          this.userprofile.City = "";
          this.userprofile.Image = "123.jpg";
          this.userprofile.PostalCode = "";
          this.userprofile.Passport = "";
          this.userprofile.AddressProof = "";
          this.userprofile.KycStatus = "";
          this.userprofile.Status = "Active";

          console.log("user profile", this.userprofile);
          
          // Add user profile
          this.service.AddUserProfile(this.userprofile).subscribe(result => {
            if (result > 0) {
              // Swal.fire('Success', 'OTP has been sent to your email. Please check your inbox to proceed.', 'success');
            } else {
              Swal.fire('Error', 'Error OTP has been sent to your email.', 'error');
            }
          });
        } 
      });
    });
  }

  isFormValid(): boolean {
    return (
      this.registration.FName && this.registration.FName.length >= 2 &&
      this.registration.LName && this.registration.LName.length >= 2 &&
      this.registration.Email && this.isEmailValid(this.registration.Email) &&
      this.registration.Password && this.registration.Password.length >= 8 &&
      this.registration.Password === this.registration.confirmPassword
    );
  }

  isEmailValid(email: string): boolean {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }
}
