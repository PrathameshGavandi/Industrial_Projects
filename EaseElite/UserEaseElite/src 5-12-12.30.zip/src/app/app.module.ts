import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import {
  GoogleLoginProvider,
  FacebookLoginProvider
} from '@abacritt/angularx-social-login';

import { CompanionDetailsComponent } from './companion-details/companion-details.component';
import { FirsttimeTravellerDetailsComponent } from './firsttime-traveller-details/firsttime-traveller-details.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { CompanionSubscriptionComponent } from './companion-subscription/companion-subscription.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FttRequestComponent } from './ftt-request/ftt-request.component';
import { FttSubscriptionComponent } from './ftt-subscription/ftt-subscription.component';
import { LoginComponent } from './login/login.component';
// import { SubscriptionComponent } from './subscription/subscription.component';
import { VerificationOtpComponent } from './verification-otp/verification-otp.component';


import { EditComponent } from './edit/edit.component';
import { PackageSenderDetailsComponent } from './package-sender-details/package-sender-details.component';
import { CarrierDetailsComponent } from './carrier-details/carrier-details.component';
import { PaymentComponent } from './payment/payment.component';
import { FttpanelComponent } from './fttpanel/fttpanel.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { CompanionpanelComponent } from './companionpanel/companionpanel.component';
import { CarrierpanelComponent } from './carrierpanel/carrierpanel.component';
import { PackagesenderpanelComponent } from './packagesenderpanel/packagesenderpanel.component';
import { PaymentDetail3Component } from './payment-detail3/payment-detail3.component';
import { PaymentDetail2Component } from './payment-detail2/payment-detail2.component';
import { CarrierSubscriptionComponent } from './carrier-subscription/carrier-subscription.component';
import { PackageSubscriptionComponent } from './package-subscription/package-subscription.component';
import { AdminPanelComponent } from './admin-panel/admin-panel.component';
import { ViewComponent } from './view/view.component';
import { CarrierviewComponent } from './carrierview/carrierview.component';
import { CompanionviewComponent } from './companionview/companionview.component';
import { PackagesenderviewComponent } from './packagesenderview/packagesenderview.component';
import { KycComponent } from './kyc/kyc.component';
import { NgxPayPalModule } from 'ngx-paypal';
import { PaymentDetailComponent } from './payment-detail/payment-detail.component';
import { CarrierDetailComponent } from './carrier-detail/carrier-detail.component';
import { CarrierDetailChackoutComponent } from './carrier-detail-chackout/carrier-detail-chackout.component';
import { CompanionDetailChackoutComponent } from './companion-detail-chackout/companion-detail-chackout.component';
import { SenderDetailChackoutComponent } from './sender-detail-chackout/sender-detail-chackout.component';
import { OtpMatchComponent } from './otp-match/otp-match.component';
import { VerifyEmailComponent } from './verify-email/verify-email.component';
// import { FacebookLoginProvider, GoogleLoginProvider, SocialAuthServiceConfig, SocialLoginModule } from '@abacritt/angularx-social-login';
import { MakerequestComponent } from './makerequest/makerequest.component';
import { FilterByPipe } from './filter-by.pipe';
import { WorldComponent } from './world/world.component';
// import { NgxPayPalModule } from 'ngx-paypal';
import { SocialLoginModule, SocialAuthServiceConfig } from '@abacritt/angularx-social-login';



@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
   
    CompanionDetailsComponent,
    FirsttimeTravellerDetailsComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    AboutusComponent,
    LoginComponent,
    ForgotPasswordComponent,
    VerificationOtpComponent,
    CompanionSubscriptionComponent,
    FeedbackComponent,
    // SubscriptionComponent,
    FttRequestComponent,
    FttSubscriptionComponent,
    KycComponent,
    EditComponent,
  
    VerifyEmailComponent,
    PackageSenderDetailsComponent,
    CarrierDetailsComponent,
    PaymentComponent,
    FttpanelComponent,
    ResetPasswordComponent,
    CompanionpanelComponent,
    CarrierpanelComponent,
    PackagesenderpanelComponent,
    PaymentDetail3Component,
    PaymentDetail2Component,
    CarrierSubscriptionComponent,
    PackageSubscriptionComponent,
    AdminPanelComponent,
    ViewComponent,
    CarrierviewComponent,
    CompanionviewComponent,
    PackagesenderviewComponent,
    PaymentDetailComponent,
    CarrierDetailComponent,
    CarrierDetailChackoutComponent,
    CompanionDetailChackoutComponent,
    SenderDetailChackoutComponent,
   
    OtpMatchComponent,
        MakerequestComponent,
        FilterByPipe,
     WorldComponent ,
     LoginComponent


  ],
  // schemas: [NO_ERRORS_SCHEMA],
  
  imports: [
    NgxPayPalModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    SocialLoginModule,
    

  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
             // '496925693986-i3markpgj2kk2f6n3rb6k6eviimv6g55.apps.googleusercontent.com'
              '188718229861-5upd898p32a51hjmgsa9etp1usnh0dlb.apps.googleusercontent.com'
              //'256869107176-efrnlcvp8v5q273kq8e3o9is8f59oje0.apps.googleusercontent.com'
            )
          },
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('clientId')
          }
        ],
        onError: (err) => {
          console.error(err);
        }
      } as SocialAuthServiceConfig,
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
