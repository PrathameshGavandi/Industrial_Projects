import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalVariable } from '../Global';
import { WebService } from '../Service';

@Component({
  selector: 'app-companion-subscription',
  templateUrl: './companion-subscription.component.html',
  styleUrls: ['./companion-subscription.component.scss']
})
export class CompanionSubscriptionComponent implements OnInit {
  companionSubscriptionList: any[] = []; // List of subscriptions
  FttPurchasePlan: any[] = [];          // List of purchased plans
  UId: any;                             // User ID
  isAnyPlanPurchased: boolean = false;  // Global flag to disable all buttons
  imgPath: string = GlobalVariable.BASE_API_URL; // Base path for images

  constructor(
    private router: Router,
    private http: HttpClient,
    private service: WebService
  ) {}

  ngOnInit(): void {
    // Retrieve user ID from session storage
    this.UId = JSON.parse(sessionStorage.getItem('SID') || 'null');

    // Fetch purchased plans first, then load subscriptions
    this.fetchPurchasedPlans().then(() => {
      this.loadSubscriptionList();
    });
  }

  /**
   * Fetch the list of purchased plans and set the global flag
   */
  private fetchPurchasedPlans(): Promise<void> {
    return new Promise((resolve) => {
      this.service.GetAllCompanionPurchasePlan().subscribe((plans) => {
        this.FttPurchasePlan = plans;
        console.log('Purchased Plans:', this.FttPurchasePlan);

        // Check if at least one plan is purchased
        this.isAnyPlanPurchased = Array.isArray(this.FttPurchasePlan) && this.FttPurchasePlan.some(
          (plan) => plan.RegistrationId === this.UId
        );

        resolve();
      });
    });
  }

  /**
   * Load all available subscription plans
   */
  private loadSubscriptionList(): void {
    this.service.GetAllAdmCompSubscription().subscribe((subscriptions) => {
      this.companionSubscriptionList = subscriptions;
      console.log('Subscription List:', this.companionSubscriptionList);
    });
  }

  /**
   * Handle the "Buy Now" button click
   * @param subscriptionId - ID of the selected subscription
   */
  onClick(subscriptionId: number): void {
    if (!this.isAnyPlanPurchased) {
      this.router.navigateByUrl('/Comppaymentdetail/' + subscriptionId);
      console.log('Navigating to payment details for subscription ID:', subscriptionId);
    }
  }
}
