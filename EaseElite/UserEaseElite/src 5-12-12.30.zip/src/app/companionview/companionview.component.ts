import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserProfile, Registration, MakeRequest, FttDetail } from '../Class';
import { GlobalVariable } from '../Global';
import { WebService } from '../Service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-companionview',
  templateUrl: './companionview.component.html',
  styleUrls: ['./companionview.component.scss']
})
export class CompanionviewComponent {
  id;
  imgPath: string = GlobalVariable.BASE_API_URL;

  userprofile = new UserProfile();
  registration = new Registration();
  allRegistration: Registration[];
  FttDetailList:FttDetail;
  SID: string;
  companionId: number | null = null;


  showPopup: boolean = false;
  requestDetail: MakeRequest;
  myFttId;
  Rlist:any[]=[]
UserProfileId: number;

  
  constructor(private route: ActivatedRoute,private router: Router, private http: HttpClient, private service: WebService) {
  
    this.registration = new Registration();
    this.userprofile.registration = new Registration();
 this.requestDetail=new MakeRequest();
 this.requestDetail = new MakeRequest();
 this.requestDetail.registration = new Registration
  
    this.FttDetailList= new FttDetail()
   this.id= sessionStorage.getItem('SID');
   console.log(" My ID",this.id);



  //  this.route.paramMap.subscribe(params => {
  //   this.companionId = +params.get('cmpId')!; // Use "+" to convert string to number
  //   console.log('Companion ID:', this.companionId);
  // });
  

  this.route.params.subscribe(params => {
    this.companionId = params['cmpId']; // From the route
  });
  
  this.route.queryParams.subscribe(queryParams => {
   this. myFttId = queryParams['myFttId']; // From the query parameters
  });


   
  }

  openPopup() {
    this.showPopup = true;
  }

  closePopup() {
    this.showPopup = false;
  }


  ngOnInit(): void {
    this.SID = sessionStorage.getItem('SID');
    this.GetInfo();
    this.GetAllFttDetail();


    this.service.GetAllUserProfile().subscribe(
      (data) => {
       this.Rlist=data
       console.log("All Registration data is ", this.Rlist);
       
        });
    }

  GetAllFttDetail(): void {

    this.service.GetCompanionDetailById(this.companionId).subscribe((result) => {
      this.FttDetailList=result
      console.log("Ftt  Info id ",this.FttDetailList);
     
        });
  }




  

  

  GetInfo(){
 
    this.service.GetRegistrationById(this.id).subscribe((result) => {
     this.registration=result
     console.log("Registration  Info",result);
    
       });

   
      this.service.GetUserProfileById(this.id).subscribe((result) => {
        this.userprofile=result
        console.log("User Info",result);
       
          });

      }
      getAllRegistrations() {
        this.service.GetAllRegistration().subscribe(
          (result: Registration[]) => {
            this.allRegistration = result;
            console.log("All Registrations", result);

            
          },
          (error) => {
            console.error("Error fetching all registrations", error);
          }
        );
}


submitRequest() {


  this.requestDetail.registration.RegistrationId=  this.id;
  this.requestDetail.TicketId= this.myFttId
  this.requestDetail.Status="Active";
  this.requestDetail.CompAgree="";
  this.requestDetail.FttAgree="Yes";
  this.requestDetail.TicketStatus=""
  this.requestDetail.Feedback="";
    this.requestDetail.CreatedBy=""


    console.log('Request Submitted:', this.requestDetail);


    this.service.AddMakeRequest(this.requestDetail).subscribe(

      (result) => {
        if (result > 0) {
        }
        else{

        }
        });

    this.showPopup = false;

}

getname(UId: number): string {
  const ResName = this.Rlist.filter(res => res.UserProfileId === UId);

  if (ResName.length > 0) {
    return `${ResName[0].Contact}`; // Return Contact
  } else {
    return 'NoImageAvailable.png'; // Default value when no matching record is found
  }
}


}