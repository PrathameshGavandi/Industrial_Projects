import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanionDetailChackoutComponent } from './companion-detail-chackout.component';

describe('CompanionDetailChackoutComponent', () => {
  let component: CompanionDetailChackoutComponent;
  let fixture: ComponentFixture<CompanionDetailChackoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompanionDetailChackoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompanionDetailChackoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
