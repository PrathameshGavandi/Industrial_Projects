import { Component, OnInit } from        '@angular/core';
import { Injectable } from        '@angular/core';
import { HttpRequest, HttpClient } from        '@angular/common/http';
import { Observable} from        'rxjs';
import { HttpHeaders } from        '@angular/common/http';

//add name of class here
// import { GlobalVariable } from        './Global';
import { Carrierdetail, Feedback, Login,MakeRequest,PackageDetail,Registration, UserProfile } from './Class';
import { GlobalVariable } from './Global';
@Injectable({
providedIn:        'root'
})

export class WebService {
  createPayPalOrder: any;
  GetFttById() {
    throw new Error('Method not implemented.');
  }
  SubmitFlightDetails: any;
    GoogleLogin(token: string) {
        throw new Error('Method not implemented.');
    }
httpOptions = {
 headers: new HttpHeaders({
        'Content-Type':  'application/json',
 "Access-Control-Allow-Headers": "Content-Type",
 "Access-Control-Allow-Methods":        'GET, POST, OPTIONS, DELETE,PUT',
 "Content-Security-Policy":        'upgrade-insecure-requests' 
  })
};
  GetUserprofileById: any;
constructor (private http: HttpClient){  }




  
Login(Email, Password): Observable<any> {
    return this.http.get<Login>(GlobalVariable.SERVICE_API_URL + "Registration/Login?Email=" + Email + "&Password=" + Password);
}

SendOTPEmail(Email){ 
  return this.http.get<any>(GlobalVariable.SERVICE_API_URL +"Registration/SendOTPEmail?Email="+Email,this.httpOptions);
}

//Registration
AddRegistration(Registration): Observable<any> {
    return this.http.post<Registration>(GlobalVariable.SERVICE_API_URL + "Registration/AddRegistration", Registration, this.httpOptions);
}
GetAllRegistration() {
    return this.http.get<any>(GlobalVariable.SERVICE_API_URL + "Registration/GetAllRegistration", this.httpOptions);
}
GetRegistrationByEmail(Email){
    return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"Registration/GetRegistrationByEmail?Email="+Email,this.httpOptions);
  }
  DeleteRegistration(RegistrationId): Observable<any> {
    return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"Registration/DeleteRegistration?RegistrationId="+RegistrationId,this.httpOptions);
  }
  GetRegistrationById(RegistrationId): Observable<any> {
    return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"Registration/GetRegistrationById?RegistrationId=" +RegistrationId, this.httpOptions);
  }
  UpdateRegistration(Registration): Observable<any> {
    return this.http.post<Registration>( GlobalVariable.SERVICE_API_URL +"Registration/UpdateRegistration",Registration, this.httpOptions);
  } 


//UserProfile
AddUserProfile(UserProfile): Observable<any> {
  return this.http.post<UserProfile>( GlobalVariable.SERVICE_API_URL +"UserProfile/AddUserProfile",UserProfile, this.httpOptions);
 }
 GetAllUserProfile()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"UserProfile/GetAllUserProfile", this.httpOptions);
 }
 DeleteUserProfile(UserProfileId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"UserProfile/DeleteUserProfile?UserProfileId="+UserProfileId, this.httpOptions);
 }
 GetUserProfileById(UserProfileId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"UserProfile/GetUserProfileById?UserProfileId="+UserProfileId, this.httpOptions);
 }
 UpdateUserProfile(UserProfile): Observable<any> {
  return this.http.post<UserProfile>( GlobalVariable.SERVICE_API_URL +"UserProfile/UpdateUserProfile",UserProfile, this.httpOptions);
 }
 SaveUserProfileImage(formdata,UserProfileId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"UserProfile/SaveUserProfileImage?UserProfileId="+UserProfileId, formdata, null );
 return this.http.request(uploadReq);
 }
 SaveKycImage(formdata,UserprofileId): Observable<any> {
  const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"UserProfile/SaveKycImage?UserProfileId="+UserprofileId, formdata, null );
  return this.http.request(uploadReq);
  }


//FttSubscription
AddFttSubscription(FttSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttSubscription/AddFttSubscription",FttSubscription, this.httpOptions);
 }
 GetAllFttSubscription()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttSubscription/GetAllFttSubscription", this.httpOptions);
 }
 DeleteFttSubscription(FttSubscriptionId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"FttSubscription/DeleteFttSubscription?FttSubscriptionId="+FttSubscriptionId, this.httpOptions);
 }
 GetFttSubscriptionById(FttSubscriptionId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttSubscription/GetFttSubscriptionById?FttSubscriptionId="+FttSubscriptionId, this.httpOptions);
 }
 UpdateFttSubscription(FttSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttSubscription/UpdateFttSubscription",FttSubscription, this.httpOptions);
 }
 SaveFttSubscriptionImage(formdata,FttSubscriptionId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"FttSubscription/SaveFttSubscriptionImage?FttSubscriptionId="+FttSubscriptionId, formdata, null );
 return this.http.request(uploadReq);
 }
 //FttTransactionDetail
 AddFttTransactionDetail(FttTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttTransactionDetail/AddFttTransactionDetail",FttTransactionDetail, this.httpOptions);
 }
 GetAllFttTransactionDetail()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttTransactionDetail/GetAllFttTransactionDetail", this.httpOptions);
 }
 DeleteFttTransactionDetail(FttTransactionDetailId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"FttTransactionDetail/DeleteFttTransactionDetail?FttTransactionDetailId="+FttTransactionDetailId, this.httpOptions);
 }
 GetFttTransactionDetailById(FttTransactionDetailId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttTransactionDetail/GetFttTransactionDetailById?FttTransactionDetailId="+FttTransactionDetailId, this.httpOptions);
 }
 UpdateFttTransactionDetail(FttTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttTransactionDetail/UpdateFttTransactionDetail",FttTransactionDetail, this.httpOptions);
 }
 SaveFttTransactionDetailImage(formdata,FttTransactionDetailId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"FttTransactionDetail/SaveFttTransactionDetailImage?FttTransactionDetailId="+FttTransactionDetailId, formdata, null );
 return this.http.request(uploadReq);
 }
 //FttPurchasePlan
 AddFttPurchasePlan(FttPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttPurchasePlan/AddFttPurchasePlan",FttPurchasePlan, this.httpOptions);
 }
 GetAllFttPurchasePlan()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttPurchasePlan/GetAllFttPurchasePlan", this.httpOptions);
 }
 DeleteFttPurchasePlan(FttPurchasePlanId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"FttPurchasePlan/DeleteFttPurchasePlan?FttPurchasePlanId="+FttPurchasePlanId, this.httpOptions);
 }
 GetFttPurchasePlanById(FttPurchasePlanId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttPurchasePlan/GetFttPurchasePlanById?FttPurchasePlanId="+FttPurchasePlanId, this.httpOptions);
 }
 UpdateFttPurchasePlan(FttPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttPurchasePlan/UpdateFttPurchasePlan",FttPurchasePlan, this.httpOptions);
 }
 SaveFttPurchasePlanImage(formdata,FttPurchasePlanId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"FttPurchasePlan/SaveFttPurchasePlanImage?FttPurchasePlanId="+FttPurchasePlanId, formdata, null );
 return this.http.request(uploadReq);
 }

//AdmCarrierSubscription
AddAdmCarrierSubscription(AdmCarrierSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"AdmCarrierSubscription/AddAdmCarrierSubscription",AdmCarrierSubscription, this.httpOptions);
 }
 GetAllAdmCarrierSubscription()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"AdmCarrierSubscription/GetAllAdmCarrierSubscription", this.httpOptions);
 
 
  
 }
 DeleteAdmCarrierSubscription(AdmCarrierSubscriptionld  ): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"AdmCarrierSubscription/DeleteAdmCarrierSubscription?AdmCarrierSubscriptionld="+AdmCarrierSubscriptionld  , this.httpOptions);
 }
 GetAdmCarrierSubscriptionById(AdmCarrierSubscriptionld  ): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"AdmCarrierSubscription/GetAdmCarrierSubscriptionById?AdmCarrierSubscriptionld="+AdmCarrierSubscriptionld  , this.httpOptions);
 
 
 }
 UpdateAdmCarrierSubscription(AdmCarrierSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"AdmCarrierSubscription/UpdateAdmCarrierSubscription",AdmCarrierSubscription, this.httpOptions);
 }
 // SaveAdmCarrierSubscriptionImage(formdata,AdmCarrierSubscriptionld  ): Observable<any> {
 // const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"AdmCarrierSubscription/SaveAdmCarrierSubscriptionImage?AdmCarrierSubscriptionld  ="+AdmCarrierSubscriptionld  , formdata, null );
 // return this.http.request(uploadReq);
 // }
 //AdmCompSubscription
 AddAdmCompSubscription(AdmCompSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"AdmCompSubscription/AddAdmCompSubscription",AdmCompSubscription, this.httpOptions);
 }
 GetAllAdmCompSubscription()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"AdmCompSubscription/GetAllAdmCompSubscription", this.httpOptions);
 }
 DeleteAdmCompSubscription(AdmCompSubscriptionld ): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"AdmCompSubscription/DeleteAdmCompSubscription?AdmCompSubscriptionld="+AdmCompSubscriptionld , this.httpOptions);
 }
 GetAdmCompSubscriptionById(AdmCompSubscriptionld ): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"AdmCompSubscription/GetAdmCompSubscriptionById?AdmCompSubscriptionld="+AdmCompSubscriptionld , this.httpOptions);
 }
 UpdateAdmCompSubscription(AdmCompSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"AdmCompSubscription/UpdateAdmCompSubscription",AdmCompSubscription, this.httpOptions);
 }
 SaveAdmCompSubscriptionImage(formdata,AdmCompSubscriptionld ): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"AdmCompSubscription/SaveAdmCompSubscriptionImage?AdmCompSubscriptionld ="+AdmCompSubscriptionld , formdata, null );
 return this.http.request(uploadReq);
 }


//AdmSenderSubscription
AddAdmSenderSubscription(AdmSenderSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"AdmSenderSubscription/AddAdmSenderSubscription",AdmSenderSubscription, this.httpOptions);
 }
 GetAllAdmSenderSubscription()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"AdmSenderSubscription/GetAllAdmSenderSubscription", this.httpOptions);
 }
 DeleteAdmSenderSubscription(AdmSenderSubscriptionld ): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"AdmSenderSubscription/DeleteAdmSenderSubscription?AdmSenderSubscriptionld="+AdmSenderSubscriptionld , this.httpOptions);
 }
 GetAdmSenderSubscriptionById(AdmSenderSubscriptionld ): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"AdmSenderSubscription/GetAdmSenderSubscriptionById?AdmSenderSubscriptionld="+AdmSenderSubscriptionld , this.httpOptions);
 }
 UpdateAdmSenderSubscription(AdmSenderSubscription): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"AdmSenderSubscription/UpdateAdmSenderSubscription",AdmSenderSubscription, this.httpOptions);
 }
 SaveAdmSenderSubscriptionImage(formdata,AdmSenderSubscriptionld ): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"AdmSenderSubscription/SaveAdmSenderSubscriptionImage?AdmSenderSubscriptionld ="+AdmSenderSubscriptionld , formdata, null );
 return this.http.request(uploadReq);
 }
 



//CompanionTransactionDetail
AddCompanionTransactionDetail(CompanionTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CompanionTransactionDetail/AddCompanionTransactionDetail",CompanionTransactionDetail, this.httpOptions);
 }
 GetAllCompanionTransactionDetail()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CompanionTransactionDetail/GetAllCompanionTransactionDetail", this.httpOptions);
 }
 DeleteCompanionTransactionDetail(CompanionTransactionDetailId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"CompanionTransactionDetail/DeleteCompanionTransactionDetail?CompanionTransactionDetailId="+CompanionTransactionDetailId, this.httpOptions);
 }
 GetCompanionTransactionDetailById(CompanionTransactionDetailId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CompanionTransactionDetail/GetCompanionTransactionDetailById?CompanionTransactionDetailId="+CompanionTransactionDetailId, this.httpOptions);
 }
 UpdateCompanionTransactionDetail(CompanionTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CompanionTransactionDetail/UpdateCompanionTransactionDetail",CompanionTransactionDetail, this.httpOptions);
 }
 SaveCompanionTransactionDetailImage(formdata,CompanionTransactionDetailId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"CompanionTransactionDetail/SaveCompanionTransactionDetailImage?CompanionTransactionDetailId="+CompanionTransactionDetailId, formdata, null );
 return this.http.request(uploadReq);
 }
 //CarrierTransactionDetail
 AddCarrierTransactionDetail(CarrierTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CarrierTransactionDetail/AddCarrierTransactionDetail",CarrierTransactionDetail, this.httpOptions);
 }
 GetAllCarrierTransactionDetail()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CarrierTransactionDetail/GetAllCarrierTransactionDetail", this.httpOptions);
 }
 DeleteCarrierTransactionDetail(CarrierTransactionDetailId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"CarrierTransactionDetail/DeleteCarrierTransactionDetail?CarrierTransactionDetailId="+CarrierTransactionDetailId, this.httpOptions);
 }
 GetCarrierTransactionDetailById(CarrierTransactionDetailId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CarrierTransactionDetail/GetCarrierTransactionDetailById?CarrierTransactionDetailId="+CarrierTransactionDetailId, this.httpOptions);
 }
 UpdateCarrierTransactionDetail(CarrierTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CarrierTransactionDetail/UpdateCarrierTransactionDetail",CarrierTransactionDetail, this.httpOptions);
 }
 SaveCarrierTransactionDetailImage(formdata,CarrierTransactionDetailId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"CarrierTransactionDetail/SaveCarrierTransactionDetailImage?CarrierTransactionDetailId="+CarrierTransactionDetailId, formdata, null );
 return this.http.request(uploadReq);
 }
 //PackageSenderTransactionDetail
 AddPackageSenderTransactionDetail(PackageSenderTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderTransactionDetail/AddPackageSenderTransactionDetail",PackageSenderTransactionDetail, this.httpOptions);
 }
 GetAllPackageSenderTransactionDetail()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderTransactionDetail/GetAllPackageSenderTransactionDetail", this.httpOptions);
 }
 DeletePackageSenderTransactionDetail(PackageSenderTansactionDetailId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderTransactionDetail/DeletePackageSenderTransactionDetail?PackageSenderTansactionDetailId="+PackageSenderTansactionDetailId, this.httpOptions);
 }
 GetPackageSenderTransactionDetailById(PackageSenderTansactionDetailId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderTransactionDetail/GetPackageSenderTransactionDetailById?PackageSenderTansactionDetailId="+PackageSenderTansactionDetailId, this.httpOptions);
 }
 UpdatePackageSenderTransactionDetail(PackageSenderTransactionDetail): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderTransactionDetail/UpdatePackageSenderTransactionDetail",PackageSenderTransactionDetail, this.httpOptions);
 }
 SavePackageSenderTransactionDetailImage(formdata,PackageSenderTansactionDetailId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"PackageSenderTransactionDetail/SavePackageSenderTransactionDetailImage?PackageSenderTansactionDetailId="+PackageSenderTansactionDetailId, formdata, null );
 return this.http.request(uploadReq);
 }
 //CompanionPurchasePlan
 AddCompanionPurchasePlan(CompanionPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CompanionPurchasePlan/AddCompanionPurchasePlan",CompanionPurchasePlan, this.httpOptions);
 }
 GetAllCompanionPurchasePlan()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CompanionPurchasePlan/GetAllCompanionPurchasePlan", this.httpOptions);
 }
 DeleteCompanionPurchasePlan(CompanionPurchasePlanId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"CompanionPurchasePlan/DeleteCompanionPurchasePlan?CompanionPurchasePlanId="+CompanionPurchasePlanId, this.httpOptions);
 }
 GetCompanionPurchasePlanById(CompanionPurchasePlanId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CompanionPurchasePlan/GetCompanionPurchasePlanById?CompanionPurchasePlanId="+CompanionPurchasePlanId, this.httpOptions);
 }
 UpdateCompanionPurchasePlan(CompanionPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CompanionPurchasePlan/UpdateCompanionPurchasePlan",CompanionPurchasePlan, this.httpOptions);
 }
 SaveCompanionPurchasePlanImage(formdata,CompanionPurchasePlanId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"CompanionPurchasePlan/SaveCompanionPurchasePlanImage?CompanionPurchasePlanId="+CompanionPurchasePlanId, formdata, null );
 return this.http.request(uploadReq);
 }
 //CarrierPurchasePlan
 AddCarrierPurchasePlan(CarrierPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CarrierPurchasePlan/AddCarrierPurchasePlan",CarrierPurchasePlan, this.httpOptions);
 }
 GetAllCarrierPurchasePlan()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CarrierPurchasePlan/GetAllCarrierPurchasePlan", this.httpOptions);
 }
 DeleteCarrierPurchasePlan(CarrierPurchasePlanId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"CarrierPurchasePlan/DeleteCarrierPurchasePlan?CarrierPurchasePlanId="+CarrierPurchasePlanId, this.httpOptions);
 }
 GetCarrierPurchasePlanById(CarrierPurchasePlanId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CarrierPurchasePlan/GetCarrierPurchasePlanById?CarrierPurchasePlanId="+CarrierPurchasePlanId, this.httpOptions);
 }
 UpdateCarrierPurchasePlan(CarrierPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CarrierPurchasePlan/UpdateCarrierPurchasePlan",CarrierPurchasePlan, this.httpOptions);
 }
 SaveCarrierPurchasePlanImage(formdata,CarrierPurchasePlanId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"CarrierPurchasePlan/SaveCarrierPurchasePlanImage?CarrierPurchasePlanId="+CarrierPurchasePlanId, formdata, null );
 return this.http.request(uploadReq);
 }
 
 //PackageSenderPurchasePlan
 AddPackageSenderPurchasePlan(PackageSenderPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderPurchasePlan/AddPackageSenderPurchasePlan",PackageSenderPurchasePlan, this.httpOptions);
 }
 GetAllPackageSenderPurchasePlan()  {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderPurchasePlan/GetAllPackageSenderPurchasePlan", this.httpOptions);
 }
 DeletePackageSenderPurchasePlan(PackageSenderPurchasePlanId): Observable<any> {
     return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderPurchasePlan/DeletePackageSenderPurchasePlan?PackageSenderPurchasePlanId="+PackageSenderPurchasePlanId, this.httpOptions);
 }
 GetPackageSenderPurchasePlanById(PackageSenderPurchasePlanId): Observable<any> {
     return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderPurchasePlan/GetPackageSenderPurchasePlanById?PackageSenderPurchasePlanId="+PackageSenderPurchasePlanId, this.httpOptions);
 }
 UpdatePackageSenderPurchasePlan(PackageSenderPurchasePlan): Observable<any> {
  return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"PackageSenderPurchasePlan/UpdatePackageSenderPurchasePlan",PackageSenderPurchasePlan, this.httpOptions);
 }
 SavePackageSenderPurchasePlanImage(formdata,PackageSenderPurchasePlanId): Observable<any> {
 const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"PackageSenderPurchasePlan/SavePackageSenderPurchasePlanImage?PackageSenderPurchasePlanId="+PackageSenderPurchasePlanId, formdata, null );
 return this.http.request(uploadReq);
 }

//UserRole
AddUserRole(UserRole): Observable<any> {
    debugger
    return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"UserRole/AddUserRole",UserRole, this.httpOptions);
   }
   GetAllUserRole()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"UserRole/GetAllUserRole", this.httpOptions);
   }
   DeleteUserRole(UserRoleId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"UserRole/DeleteUserRole?UserRoleId="+UserRoleId, this.httpOptions);
   }
   GetUserRoleById(UserRoleId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"UserRole/GetUserRoleById?UserRoleId="+UserRoleId, this.httpOptions);
   }
   UpdateUserRole(UserRole): Observable<any> {
    return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"UserRole/UpdateUserRole",UserRole, this.httpOptions);
   }
   SaveUserRoleImage(formdata,UserRoleId): Observable<any> {
   const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"UserRole/SaveUserRoleImage?UserRoleId="+UserRoleId, formdata, null );
   return this.http.request(uploadReq);
   }



   //CompanionDetail
AddCompanionDetail(CompanionDetail): Observable<any> {
    return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CompanionDetail/AddCompanionDetail",CompanionDetail, this.httpOptions);
   }
   GetAllCompanionDetail()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CompanionDetail/GetAllCompanionDetail", this.httpOptions);
   }
   DeleteCompanionDetail(CompanionId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"CompanionDetail/DeleteCompanionDetail?CompanionId="+CompanionId, this.httpOptions);
   }
   GetCompanionDetailById(CompanionId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CompanionDetail/GetCompanionDetailById?CompanionId="+CompanionId, this.httpOptions);
   }
   UpdateCompanionDetail(CompanionDetail): Observable<any> {
    return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"CompanionDetail/UpdateCompanionDetail",CompanionDetail, this.httpOptions);
   }
   SaveCompanionDetailImage(formdata,CompanionId): Observable<any> {
   const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"CompanionDetail/SaveCompanionDetailImage?CompanionId="+CompanionId, formdata, null );
   return this.http.request(uploadReq);
   }
   //FttDetail
   AddFttDetail(FttDetail): Observable<any> {
    return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttDetail/AddFttDetail",FttDetail, this.httpOptions);
   }
   GetAllFttDetail()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttDetail/GetAllFttDetail", this.httpOptions);
   }
   DeleteFttDetail(FttId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"FttDetail/DeleteFttDetail?FttId="+FttId, this.httpOptions);
   }
   GetFttDetailById(FttId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"FttDetail/GetFttDetailById?FttId="+FttId, this.httpOptions);
   }
   UpdateFttDetail(FttDetail): Observable<any> {
    return this.http.post<any>( GlobalVariable.SERVICE_API_URL +"FttDetail/UpdateFttDetail",FttDetail, this.httpOptions);
   }
   SaveFttDetailImage(formdata,FttId): Observable<any> {
   const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"FttDetail/SaveFttDetailImage?FttId="+FttId, formdata, null );
   return this.http.request(uploadReq);
   }





//MakeRequest
AddMakeRequest(MakeRequest): Observable<any> {
    return this.http.post<MakeRequest>( GlobalVariable.SERVICE_API_URL +"MakeRequest/AddMakeRequest",MakeRequest, this.httpOptions);
   }
   GetAllMakeRequest()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"MakeRequest/GetAllMakeRequest", this.httpOptions);
   }
   DeleteMakeRequest(MakeRequestId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"MakeRequest/DeleteMakeRequest?MakeRequestId="+MakeRequestId, this.httpOptions);
   }
   GetMakeRequestById(MakeRequestId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"MakeRequest/GetMakeRequestById?MakeRequestId="+MakeRequestId, this.httpOptions);
   }
   UpdateMakeRequest(MakeRequest): Observable<any> {
    return this.http.post<MakeRequest>( GlobalVariable.SERVICE_API_URL +"MakeRequest/UpdateMakeRequest",MakeRequest, this.httpOptions);
   }
   SaveMakeRequestImage(formdata,MakeRequestId): Observable<any> {
   const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"MakeRequest/SaveMakeRequestImage?MakeRequestId="+MakeRequestId, formdata, null );
   return this.http.request(uploadReq);
   }

//CarrierDetail
AddCarrierDetail(CarrierDetail): Observable<any> {
    return this.http.post<Carrierdetail>( GlobalVariable.SERVICE_API_URL +"CarrierDetail/AddCarrierDetail",CarrierDetail, this.httpOptions);
   }
   GetAllCarrierDetail()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CarrierDetail/GetAllCarrierDetail", this.httpOptions);
   }
   DeleteCarrierDetail(CarrierDetailId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"CarrierDetail/DeleteCarrierDetail?CarrierDetailId="+CarrierDetailId, this.httpOptions);
   }
   GetCarrierDetailById(CarrierDetailId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"CarrierDetail/GetCarrierDetailById?CarrierDetailId="+CarrierDetailId, this.httpOptions);
   }
   UpdateCarrierDetail(CarrierDetail): Observable<any> {
    return this.http.post<Carrierdetail>( GlobalVariable.SERVICE_API_URL +"CarrierDetail/UpdateCarrierDetail",CarrierDetail, this.httpOptions);
   }
   SaveCarrierDetailImage(formdata,CarrierDetailId): Observable<any> {
   const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"CarrierDetail/SaveCarrierDetailImage?CarrierDetailId="+CarrierDetailId, formdata, null );
   return this.http.request(uploadReq);
   }
   //PackageDetail
   AddPackageDetail(PackageDetail): Observable<any> {
    return this.http.post<PackageDetail>( GlobalVariable.SERVICE_API_URL +"PackageDetail/AddPackageDetail",PackageDetail, this.httpOptions);
   }
   GetAllPackageDetail()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"PackageDetail/GetAllPackageDetail", this.httpOptions);
   }
   DeletePackageDetail(PackageDetailId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"PackageDetail/DeletePackageDetail?PackageDetailId="+PackageDetailId, this.httpOptions);
   }
   GetPackageDetailById(PackageDetailId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"PackageDetail/GetPackageDetailById?PackageDetailId="+PackageDetailId, this.httpOptions);
   }
   UpdatePackageDetail(PackageDetail): Observable<any> {
    return this.http.post<PackageDetail>( GlobalVariable.SERVICE_API_URL +"PackageDetail/UpdatePackageDetail",PackageDetail, this.httpOptions);
   }
   SavePackageDetailImage(formdata,PackageDetailId): Observable<any> {
   const uploadReq = new  HttpRequest('Post',GlobalVariable.SERVICE_API_URL +"PackageDetail/SavePackageDetailImage?PackageDetailId="+PackageDetailId, formdata, null );
   return this.http.request(uploadReq);
   }


  
   //Feedback
   AddFeedback(Feedback): Observable<any> {
    return this.http.post<Feedback>( GlobalVariable.SERVICE_API_URL +"Feedback/AddFeedback",Feedback, this.httpOptions);
   }
   GetAllFeedback()  {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"Feedback/GetAllFeedback", this.httpOptions);
   }
   DeleteFeedback(FeedbackId): Observable<any> {
       return this.http.delete<any>( GlobalVariable.SERVICE_API_URL +"Feedback/DeleteFeedback?FeedbackId="+FeedbackId, this.httpOptions);
   }
   GetFeedbackById(FeedbackId): Observable<any> {
       return this.http.get<any>( GlobalVariable.SERVICE_API_URL +"Feedback/GetFeedbackById?FeedbackId="+FeedbackId, this.httpOptions);
   }
   UpdateFeedback(Feedback): Observable<any> {
    return this.http.post<Feedback>( GlobalVariable.SERVICE_API_URL +"Feedback/UpdateFeedback",Feedback, this.httpOptions);
   }













   }
   




